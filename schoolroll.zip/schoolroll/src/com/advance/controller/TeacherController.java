package com.advance.controller;

import java.net.URLDecoder;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.advance.Util.Json;
import com.advance.Util.Result;
import com.advance.Util.UUIDTool;
import com.advance.model.Teacher;
import com.advance.model.User;
import com.advance.service.TeacherService;
import com.advance.service.UserService;

@Controller
@RequestMapping("/Teacher")
public class TeacherController {

	@Resource
	private TeacherService TeacherService;
	@Resource
	private UserService userservice;

	/**
	 * 查询
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Select.do", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Select(HttpServletResponse response) throws Exception {
		try {
			List<Teacher> Teachers = TeacherService.SelectTeachers();
			if (Teachers != null && Teachers.size() != 0) {
				Json.toJson(Teachers, response);
			} else {
				Json.toJson(new Result(false,"数据不存在"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 删除
	 * @param ID
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Delete.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void delete(String ID,HttpServletResponse response) throws Exception {
		try {
			int i = TeacherService.deleteByPrimaryKey(ID);
			if (i > 0) {
				Result result = new Result(true,"删除成功");
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"删除失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 插入
	 * @param Teacher
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Insert.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Insert(Teacher Teacher,HttpServletRequest request,HttpServletResponse response) throws Exception {
		try {
			Teacher.setId(UUIDTool.getUUID());
			Cookie[] cookies = request.getCookies();//根据请求数据，找到cookie数组

	        if (null==cookies) {
	        	Json.toJson(new Result(false,"插入失败"), response);
	        } else {
	            for(Cookie cookie : cookies){
	                if(cookie.getName().equals("userid")){
	                	Teacher.setCreateuserid(cookie.getValue());
	                }
	                if(cookie.getName().equals("username")){ 
	                	Teacher.setCreateusername(URLDecoder.decode(cookie.getValue(), "UTF-8"));
	                }
	            }
	        }
			Teacher.setCreatetime(new Date());
			
			User user= new User();
			
			user.setId(UUIDTool.getUUID());
			user.setUserid(Teacher.getTeacherid());
			user.setUsername(Teacher.getTeachername());
			user.setUserpassword("123456");
			user.setUserstate(true);
			user.setUsertype("teacher");
	        if (null==cookies) {
	        	Json.toJson(new Result(false,"插入失败"), response);
	        } else {
	            for(Cookie cookie : cookies){
	                if(cookie.getName().equals("userid")){
	                	user.setCreateuserid(cookie.getValue());
	                }
	                if(cookie.getName().equals("username")){ 
	                	user.setCreateusername(URLDecoder.decode(cookie.getValue(), "UTF-8"));
	                }
	            }
	        }
			user.setCreatetime(new Date());
			
			int useradd = userservice.insert(user);
			int i = TeacherService.insert(Teacher);
			if (i > 0&&useradd>0) {
				Result result = new Result(true,"插入成功",Teacher);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"插入失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 更新
	 * @param Teacher
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Update.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Update(Teacher Teacher,HttpServletResponse response) throws Exception {
		try {
			int i = TeacherService.updateByPrimaryKey(Teacher);
			if (i > 0) {
				Result result = new Result(true,"更新成功",Teacher);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"更新失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	

}
