package com.advance.controller;

import java.io.InputStream;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.advance.Util.Json;
import com.advance.Util.Result;
import com.advance.Util.UUIDTool;
import com.advance.mapper.ClassMapper;
import com.advance.mapper.CollegeMapper;
import com.advance.mapper.MajorMapper;
import com.advance.model.Achievement;
import com.advance.model.College;
import com.advance.model.Major;
import com.advance.model.Schoolroll;
import com.advance.model.User;
import com.advance.service.AchievementService;
import com.advance.service.SchoolrollService;
import com.advance.service.UserService;

@Controller
@RequestMapping("/Schoolroll")
public class SchoolrollController {

	@Resource
	private SchoolrollService SchoolrollService;
	@Resource
	private AchievementService achievementservice;
	@Resource
	private UserService UserService;
	@Resource
	private CollegeMapper collegemapper;
	@Resource
	private MajorMapper majormapper;
	@Resource
	private ClassMapper classmapper;
	
	/**
	 * 查询
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Select.do", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Select(HttpServletResponse response) throws Exception {
		try {
			List<Schoolroll> Schoolrolls = SchoolrollService.SelectSchoolrolls();
			if (Schoolrolls != null && Schoolrolls.size() != 0) {
				Json.toJson(Schoolrolls, response);
			} else {
				Json.toJson(new Result(false,"数据不存在"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	/**
	 * 查询
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/SelectBySchoolRollID.do", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void SelectBySchoolRollID(HttpServletRequest request,HttpServletResponse response) throws Exception {
		try {
			
			Cookie[] cookies = request.getCookies();//根据请求数据，找到cookie数组

	        if (null==cookies) {
	        	Json.toJson(new Result(false,"登录状态异常，请重新登录"), response);
	        	return;
	        }
	        
	        String userid=null;
	        for(Cookie cookie : cookies){
                if(cookie.getName().equals("userid")){
                	userid=cookie.getValue();
                }
            }
	        
			Schoolroll Schoolrolls = SchoolrollService.SelectSchoolrollsBySchoolRollID(userid);
			if (Schoolrolls != null) {
				
				Result result = new Result(true,"查询成功",Schoolrolls);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"学籍信息不存在"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 删除
	 * @param ID
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Delete.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Delete(String ID,HttpServletResponse response) throws Exception {
		try {
           
			List<Achievement> achievement = achievementservice.SelectAchievementsBySchoolRollID(ID);
			
			if(achievement.size()!=0)
			{
				Json.toJson(new Result(false,"该学籍已被成绩调用，不可删除"), response);
				return;
			}
			int i = SchoolrollService.deleteByPrimaryKey(ID);
			if (i > 0) {
				Result result = new Result(true,"删除成功");
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"删除失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 插入
	 * @param Schoolroll
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Insert.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Insert(Schoolroll Schoolroll,HttpServletRequest request,HttpServletResponse response) throws Exception {
		try {
			if(Schoolroll.getIdentitycard().length()<18){
				Json.toJson(new Result(false,"身份证错误"), response);
			}
			Schoolroll.setId(UUIDTool.getUUID());
			Cookie[] cookies = request.getCookies();//根据请求数据，找到cookie数组

	        if (null==cookies) {
	        	Json.toJson(new Result(false,"插入失败"), response);
	        } else {
	            for(Cookie cookie : cookies){
	                if(cookie.getName().equals("userid")){
	                	Schoolroll.setCreateuserid(cookie.getValue());
	                }
	                if(cookie.getName().equals("username")){ 
	                	Schoolroll.setCreateusername(URLDecoder.decode(cookie.getValue(), "UTF-8"));
	                }
	            }
	        }
			Schoolroll.setCreatetime(new Date());
			int i = SchoolrollService.insert(Schoolroll);
			if (i > 0) {
				User user = new User();
				
				user.setId(UUIDTool.getUUID());
				user.setUserid(Schoolroll.getSchoolrollid());
				user.setUsername(Schoolroll.getName());
				
				String str = Schoolroll.getIdentitycard().toString();
				user.setUserpassword(str.substring(str.length()-6,str.length()));
				
				user.setUserstate(true);
				user.setUsertype("student");
				user.setCreateuserid(Schoolroll.getCreateuserid());
				user.setCreateusername(Schoolroll.getCreateusername());
				user.setCreatetime(new Date());
				int j = UserService.insert(user);
				if(j > 0){
					
					Result result = new Result(true,"用户插入成功",Schoolroll);
					Json.toJson(result, response);
				}else {
					Json.toJson(new Result(false,"用户插入失败"), response);
					return;
				}
				
				Result result = new Result(true,"学籍插入成功",Schoolroll);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"学籍插入失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 导入
	 * @param Schoolroll
	 * @param response
	 * @throws Exception
	 */
	
	@SuppressWarnings("deprecation")
	@RequestMapping(value = "/Import.do",method = RequestMethod.POST)
	@ResponseBody
	public void Import(@RequestParam(value = "filename", required = false) MultipartFile filename,HttpServletRequest request,HttpServletResponse response) throws Exception {
		try {
			
			String userid=null;
			
			String username=null;
			
			Cookie[] cookies = request.getCookies();//根据请求数据，找到cookie数组

	        if (null==cookies) {
	        	Json.toJson(new Result(false,"登录状态异常，请重新登录"), response);
	        	return;
	        } else {
	            for(Cookie cookie : cookies){
	                if(cookie.getName().equals("userid")){
	                	userid=cookie.getValue();
	                }
	                if(cookie.getName().equals("username")){ 
	                	username=URLDecoder.decode(cookie.getValue(), "UTF-8");
	                }
	            }
	        }
			
	        if(userid==null||username==null)
	        {
	        	Json.toJson(new Result(false,"登录状态异常，请重新登录"), response);
	        	return;
	        }
	        
			if(!filename.isEmpty())
			{
				String excelname=filename.getOriginalFilename();
				
                int index = excelname.lastIndexOf(".");  
                
                String suffix = excelname.substring(index).toLowerCase();  
                
                // 验证文件格式  
                if(!suffix.equals(".xlsx") && !suffix.equals(".xls")) {
                	
                   Json.toJson(new Result(false, "导入文件格式不对"), response);
                   
                   return;
                }  
               
				InputStream excelstream = filename.getInputStream(); //获取文件输入流  
				 
				Workbook wookbook = (Workbook) WorkbookFactory.create(excelstream);
				 
				Sheet sheet = wookbook.getSheetAt(0);  //获取Excel的第一个子页  
				 
				int rowcount=sheet.getPhysicalNumberOfRows();//获取最大行数
				
				//判断数据行数
				if(rowcount<2)
				{
					Json.toJson(new Result(false, "导入文件不存在数据"), response);
					
	                return;
					
				}
							
				List<Schoolroll> schoolrolllist=new ArrayList<Schoolroll>();
				
				Schoolroll schoolrollitem;
				
			    Row row=null;
			   
			    for(int i=1;i<rowcount;i++){ 
			    	
			        row = sheet.getRow(i);  //第几个格子  
			        
		            int colnum = row.getPhysicalNumberOfCells();//获取最大列数
		            
		            //判断当前行的列数
		            if(colnum!=14)
		            {
		            	//System.out.println("列数不合格");
		            	continue;	
		            }
		           System.out.println(row.getCell(3).toString());
		            //判断日期格式是否合法 身份证是否为18位
		            if(!IsValidDate(row.getCell(3).toString()))
		            {	 
		            	
		            	System.out.println("出生年月日期格式不合格");
		            	continue;
		            }
		            
		           //身份证是否为18位
		            if(row.getCell(7).toString().length()!=18)
		            {
		            	System.out.println(row.getCell(7).toString().length());
		            	System.out.println(row.getCell(7).toString());
		            	System.out.println("身份证格式不合格");
		            	continue;
		            }
		            
		           //判断日期格式是否合法 
		            if(!IsValidDate(row.getCell(9).toString()))
		            {	  
		            	System.out.println("入学时间日期格式不合格");
		            	continue;
		            }
		            
		            College college=collegemapper.SelectByCollegeName(row.getCell(11).toString());
		            
		            if(college==null)
		            {		 
		            	System.out.println("学院不存在");
		            	continue;
		            }
		            
                    Major major=majormapper.SelectByMajorName(row.getCell(12).toString());
		            
		            if(major==null)
		            {		        
		            	System.out.println("专业不存在");
		            	continue;
		            }
		            
		            com.advance.model.Class classs=classmapper.SelectByClassName(row.getCell(13).toString());
		            
		            if(classs==null)
		            {		
		            	System.out.println("班级不存在");
		            	continue;
		            }
		            
		            schoolrollitem=new Schoolroll();
		            
		            schoolrollitem.setId(UUIDTool.getUUID());
		            
                    schoolrollitem.setSchoolrollid(row.getCell(0).toString());
		            
		            schoolrollitem.setName(row.getCell(1).toString());
		            
		            schoolrollitem.setSex(row.getCell(2).toString());
		            
                    schoolrollitem.setBirthday(new Date(row.getCell(3).toString()));
		            
		            schoolrollitem.setNation(row.getCell(4).toString());
		            
		            schoolrollitem.setBirthplace(row.getCell(5).toString());
		            
                    schoolrollitem.setAddress(row.getCell(6).toString());
		            
		            schoolrollitem.setIdentitycard(row.getCell(7).toString());
		            
		            schoolrollitem.setZipcode(row.getCell(8).toString());
		            
                    schoolrollitem.setEntrancedate(new Date(row.getCell(9).toString()));
		            
		            schoolrollitem.setEducation(row.getCell(10).toString());
		            
		            schoolrollitem.setCollegeid(college.getId());
		            
                    schoolrollitem.setMajorid(major.getId());
		            
		            schoolrollitem.setClassid(classs.getId());          
		            	            
		            schoolrollitem.setCreateuserid(userid);
		            
		            schoolrollitem.setCreateusername(username);
		            
		            schoolrollitem.setCreatetime(new Date());
					
		            schoolrolllist.add(schoolrollitem);
		            
			    }
			    
			    if(schoolrolllist.size()==0)
			    {
			    	Json.toJson(new Result(false, "导入文件不存在有效数据"), response);
			    	return;
			    }
			    
			    for(Schoolroll x:schoolrolllist)
			    {
			    	
			    	    SchoolrollService.insert(x);
						User user = new User();					
						user.setId(UUIDTool.getUUID());
						user.setUserid(x.getSchoolrollid());
						user.setUsername(x.getName());
						user.setUserpassword(x.getIdentitycard().substring(x.getIdentitycard().length()-6,x.getIdentitycard().length()));
						user.setUserstate(true);
						user.setUsertype("student");
						user.setCreateuserid(userid);
						user.setCreateusername(username);
						user.setCreatetime(new Date());
					    UserService.insert(user);
			    }
			    
			    Json.toJson(new Result(true, "导入成功"), response);
			}
			else
			{
				Json.toJson(new Result(false, "导入文件不存在"), response);
			}
            
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	private boolean IsValidDate(String str) {
	       boolean convertSuccess=true;
	       SimpleDateFormat format = new SimpleDateFormat("yyyy/MM/dd");
	       try {
	    	   
	          format.setLenient(false);
	          format.parse(str);
	       } catch (ParseException e) {
	    	   
	           convertSuccess=false;
	    	  // convertSuccess = true;
	       } 
	       return convertSuccess;
	}
	
	/**
	 * 更新
	 * @param Schoolroll
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Update.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Update(Schoolroll Schoolroll,HttpServletResponse response) throws Exception {
		try {
			int i = SchoolrollService.updateByPrimaryKey(Schoolroll);
			if (i > 0) {
				Result result = new Result(true,"更新成功",Schoolroll);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"更新失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	

}
