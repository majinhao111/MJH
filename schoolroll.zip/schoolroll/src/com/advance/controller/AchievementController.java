package com.advance.controller;

import java.net.URLDecoder;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.advance.Util.Json;
import com.advance.Util.Result;
import com.advance.Util.UUIDTool;
import com.advance.model.Achievement;
import com.advance.model.Schoolroll;
import com.advance.service.AchievementService;
import com.advance.service.SchoolrollService;

@Controller
@RequestMapping("/Achievement")
public class AchievementController {

	@Resource
	private AchievementService achievementService;
	@Resource
	private SchoolrollService SchoolrollService;
	/**
	 * 查询
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Select.do", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Select(String ClassID,HttpServletResponse response) throws Exception {
		try {
			
			List<Achievement> achievements = achievementService.SelectAchievements();
			
			if(!ClassID.equals("全部"))
			{
				achievements = achievementService.SelectAchievementsByClassID(ClassID);		
			}
			
			if (achievements != null && achievements.size() != 0) {
				Json.toJson(achievements, response);
			} else {
				Json.toJson(new Result(false,"数据不存在"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 查询
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/SelectBySchoolRollID.do", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void SelectBySchoolRollID(HttpServletRequest request,HttpServletResponse response) throws Exception {
		try {
			
			Cookie[] cookies = request.getCookies();//根据请求数据，找到cookie数组

	        if (null==cookies) {
	        	Json.toJson(new Result(false,"登录状态异常，请重新登录"), response);
	        	return;
	        }
	        
	        String userid=null;
	        for(Cookie cookie : cookies){
                if(cookie.getName().equals("userid")){
                	userid=cookie.getValue();
                }
            }
	        
	        Schoolroll Schoolrolls = SchoolrollService.SelectSchoolrollsBySchoolRollID(userid);
	        
	        if (Schoolrolls==null) {
	        	Json.toJson(new Result(false,"学籍信息不存在"), response);
	        	return;
	        }
	        
			List<Achievement> achievements = achievementService.SelectAchievementsBySchoolRollID(Schoolrolls.getId());
			if (achievements != null && achievements.size() != 0) {
				Json.toJson(achievements, response);
			} else {
				Json.toJson(new Result(false,"数据不存在"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 删除
	 * @param ID
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Delete.do",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Delete(String ID,HttpServletResponse response) throws Exception {
		try {
			int i = achievementService.deleteByPrimaryKey(ID);
			if (i > 0) {
				Result result = new Result(true,"删除成功");
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"删除失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 插入
	 * @param achievement
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Insert.do",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Insert(Achievement achievement,HttpServletRequest request,HttpServletResponse response) throws Exception {
		try {
			achievement.setId(UUIDTool.getUUID());
			Cookie[] cookies = request.getCookies();//根据请求数据，找到cookie数组

	        if (null==cookies) {
	        	Json.toJson(new Result(false,"插入失败"), response);
	        } else {
	            for(Cookie cookie : cookies){
	                if(cookie.getName().equals("userid")){
	                	achievement.setCreateuserid(cookie.getValue());
	                }
	                if(cookie.getName().equals("username")){ 
	                	achievement.setCreateusername(URLDecoder.decode(cookie.getValue(), "UTF-8"));
	                }
	            }
	        }
			achievement.setCreatetime(new Date());
			int i = achievementService.insert(achievement);
			if (i > 0) {
				Result result = new Result(true,"插入成功",achievement);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"插入失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 更新
	 * @param achievement
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Update.do",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Update(Achievement achievement,HttpServletResponse response) throws Exception {
		try {
			int i = achievementService.updateByPrimaryKey(achievement);
			if (i > 0) {
				Result result = new Result(true,"更新成功",achievement);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"更新失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	

}
