package com.advance.controller;

import java.net.URLDecoder;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.advance.Util.Json;
import com.advance.Util.Result;
import com.advance.Util.UUIDTool;
import com.advance.model.Notice;
import com.advance.service.NoticeService;

@Controller
@RequestMapping("/Notice")
public class NoticeController {
	@Resource
	private NoticeService noticeservice;
	/**
	 * 查询
	 */
	@RequestMapping(value = "/Select.do", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Select(HttpServletResponse response) throws Exception {
		try {
			List<Notice> notice = noticeservice.selectNotices();
			if (notice != null && notice.size() > 0) {
				Json.toJson(notice, response);
			} else 
			{
				Json.toJson(new Result(false,"查询的数据不存在"), response);
				return;
			}
		} catch (Exception ex) 
		{
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 删除
	 * @param ID
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Delete.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Delete(String ID,HttpServletResponse response) throws Exception {
		try {
			int i = noticeservice.deleteByPrimaryKey(ID);
			if (i > 0) {
				Result result = new Result(true,"删除成功");
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"删除失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	@RequestMapping(value = "/Insert.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Insert(Notice notice,HttpServletRequest request,HttpServletResponse response) throws Exception {
		try {
			notice.setId(UUIDTool.getUUID());
			Cookie[] cookies = request.getCookies();//根据请求数据，找到cookie数组

	        if (null==cookies) {
	        	Json.toJson(new Result(false,"插入失败"), response);
	        } else {
	            for(Cookie cookie : cookies){
	                if(cookie.getName().equals("userid")){
	                	notice.setCreateuserid(cookie.getValue());
	                }
	                if(cookie.getName().equals("username")){ 
	                	notice.setCreateusername(URLDecoder.decode(cookie.getValue(), "UTF-8"));
	                }
	            }
	        }
			notice.setCreatetime(new Date());
			int i = noticeservice.insert(notice);
			if (i > 0) {
				Result result = new Result(true,"插入成功",notice);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"插入失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	@RequestMapping(value = "/Update.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Update(Notice notice,HttpServletResponse response) throws Exception {
		try {
			int i = noticeservice.updateByPrimaryKeySelective(notice);
			if (i > 0) {
				Result result = new Result(true,"更新成功",notice);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"更新失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
}
