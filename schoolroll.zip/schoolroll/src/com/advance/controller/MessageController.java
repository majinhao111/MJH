package com.advance.controller;

import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.advance.Util.Json;
import com.advance.Util.Result;
import com.advance.Util.UUIDTool;
import com.advance.model.Message;
import com.advance.model.MessageList;
import com.advance.service.MessageService;

@Controller
@RequestMapping("/Message")
public class MessageController {

	@Resource
	private MessageService MessageService;

	/**
	 * 查询
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Select.do", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Select(HttpServletResponse response) throws Exception {
		try {
			List<Message> Messages = MessageService.SelectMessages();
			
			if (Messages != null && Messages.size() != 0) {
				Json.toJson(Messages, response);
			} else {
				Json.toJson(new Result(false,"数据不存在"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	
	/**
	 * 查询
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/SelectList.do", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void SelectList(HttpServletResponse response) throws Exception {
		try {
			List<Message> Messages = MessageService.SelectMessages();
			
			if (Messages != null && Messages.size() != 0) {
				
				List<MessageList> messagelist =new ArrayList<MessageList>();
				
				for(Message x : Messages)
				{
					MessageList item =new MessageList();
					item.setId(x.getId());
					item.setContent(x.getContent());
					item.setCreateuserid(x.getCreateuserid());
					item.setCreateusername(x.getCreateusername());
					item.setCreatetime(x.getCreatetime());
					
					List<Message> MessageItem = MessageService.SelectMessagesBySourceID(x.getId());
					if (MessageItem != null && MessageItem.size() != 0) {
						item.setMessagelist(MessageItem);
					}
					else
					{
						item.setMessagelist(null);
					}
					messagelist.add(item);
				}
				
				Result result = new Result(messagelist);
				
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"数据不存在"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 删除
	 * @param ID
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Delete.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Delete(String ID,HttpServletResponse response) throws Exception {
		try {
			int i = MessageService.deleteByPrimaryKey(ID);
			MessageService.DeleteBySourceID(ID);
			if (i > 0) {
				Result result = new Result(true,"删除成功");
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"删除失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 插入
	 * @param Message
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Insert.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Insert(Message Message,HttpServletRequest request,HttpServletResponse response) throws Exception {
		try {
			Message.setId(UUIDTool.getUUID());
			Cookie[] cookies = request.getCookies();//根据请求数据，找到cookie数组

	        if (null==cookies) {
	        	Json.toJson(new Result(false,"插入失败"), response);
	        } else {
	            for(Cookie cookie : cookies){
	                if(cookie.getName().equals("userid")){
	                	System.out.println(cookie.getValue());
	                	Message.setCreateuserid(cookie.getValue());
	                }
	                if(cookie.getName().equals("username")){
	                	System.out.println(URLDecoder.decode(cookie.getValue()));
	                	Message.setCreateusername(URLDecoder.decode(cookie.getValue(), "UTF-8"));
	                }
	            }
	        }
			Message.setCreatetime(new Date());
			int i = MessageService.insert(Message);
			if (i > 0) {
				Result result = new Result(true,"插入成功",Message);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"插入失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 更新
	 * @param Message
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Update.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Update(Message Message,HttpServletResponse response) throws Exception {
		try {
			int i = MessageService.updateByPrimaryKeySelective(Message);
			if (i > 0) {
				Result result = new Result(true,"更新成功",Message);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"更新失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	

}
