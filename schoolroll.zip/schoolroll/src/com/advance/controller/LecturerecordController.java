package com.advance.controller;

import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.advance.Util.Json;
import com.advance.Util.Result;
import com.advance.Util.UUIDTool;
import com.advance.model.Lecturerecord;
import com.advance.service.LecturerecordService;

@Controller
@RequestMapping("/Lecturerecord")
public class LecturerecordController {

	@Resource
	private LecturerecordService LecturerecordService;

	/**
	 * 查询
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Select.do", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Select(HttpServletResponse response) throws Exception {
		try {
			List<Lecturerecord> Lecturerecords = LecturerecordService.SelectLecturerecords();
			if (Lecturerecords != null && Lecturerecords.size() != 0) {
				Json.toJson(Lecturerecords, response);
			} else {
				Json.toJson(new Result(false,"数据不存在"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 删除
	 * @param ID
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/delete.do",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void delete(String ID,HttpServletResponse response) throws Exception {
		try {
			int i = LecturerecordService.deleteByPrimaryKey(ID);
			if (i > 0) {
				Result result = new Result(true,"删除成功");
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"删除失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 插入
	 * @param Lecturerecord
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Insert.do",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Insert(Lecturerecord Lecturerecord,HttpServletRequest request,HttpServletResponse response) throws Exception {
		try {
			Lecturerecord.setId(UUIDTool.getUUID());
			int i = LecturerecordService.insert(Lecturerecord);
			if (i > 0) {
				Result result = new Result(true,"插入成功",Lecturerecord);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"插入失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 更新
	 * @param Lecturerecord
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Update.do",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Update(Lecturerecord Lecturerecord,HttpServletResponse response) throws Exception {
		try {
			int i = LecturerecordService.updateByPrimaryKey(Lecturerecord);
			if (i > 0) {
				Result result = new Result(true,"更新成功",Lecturerecord);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"更新失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	

}
