package com.advance.controller;

import java.net.URLDecoder;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.advance.Util.Json;
import com.advance.Util.Result;
import com.advance.Util.UUIDTool;
import com.advance.model.Achievement;
import com.advance.model.Curriculum;
import com.advance.service.AchievementService;
import com.advance.service.CurriculumService;

@Controller
@RequestMapping("/Curriculum")
public class CurriculumController {

	@Resource
	private CurriculumService CurriculumService;
	@Resource
	private AchievementService achievementservice;
	/**
	 * 查询
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Select.do", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Select(HttpServletResponse response) throws Exception {
		try {
			List<Curriculum> Curriculums = CurriculumService.SelectCurriculums();
			if (Curriculums != null && Curriculums.size() != 0) {
				Json.toJson(Curriculums, response);
			} else {
				Json.toJson(new Result(false,"数据不存在"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 删除
	 * @param ID
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Delete.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Delete(String ID,HttpServletResponse response) throws Exception {
		try {
			
            List<Achievement> achievement = achievementservice.SelectAchievementsByCurriculumID(ID);
			
			if(achievement.size()!=0)
			{
				Json.toJson(new Result(false,"该课程已被成绩调用，不可删除"), response);
				return;
			}
			int i = CurriculumService.deleteByPrimaryKey(ID);
			if (i > 0) {
				Result result = new Result(true,"删除成功");
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"删除失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 插入
	 * @param Curriculum
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Insert.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Insert(Curriculum Curriculum,HttpServletRequest request,HttpServletResponse response) throws Exception {
		try {
			Curriculum.setId(UUIDTool.getUUID());
			Cookie[] cookies = request.getCookies();//根据请求数据，找到cookie数组

	        if (null==cookies) {
	        	Json.toJson(new Result(false,"插入失败"), response);
	        } else {
	            for(Cookie cookie : cookies){
	                if(cookie.getName().equals("userid")){
	                	Curriculum.setCreateuserid(cookie.getValue());
	                }
	                if(cookie.getName().equals("username")){ 
	                	Curriculum.setCreateusername(URLDecoder.decode(cookie.getValue(), "UTF-8"));
	                }
	            }
	        }
			Curriculum.setCreatetime(new Date());
			int i = CurriculumService.insert(Curriculum);
			if (i > 0) {
				Result result = new Result(true,"插入成功",Curriculum);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"插入失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 更新
	 * @param Curriculum
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Update.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Update(Curriculum Curriculum,HttpServletResponse response) throws Exception {
		try {
			int i = CurriculumService.updateByPrimaryKey(Curriculum);
			if (i > 0) {
				Result result = new Result(true,"更新成功",Curriculum);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"更新失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	

}
