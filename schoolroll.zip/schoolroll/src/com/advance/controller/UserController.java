package com.advance.controller;

import java.net.URLDecoder;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.advance.Util.Json;
import com.advance.Util.Result;
import com.advance.Util.UUIDTool;
import com.advance.model.User;
import com.advance.service.UserService;

@Controller
@RequestMapping("/User")
public class UserController {

	@Resource
	private UserService userService;

	/**
	 * 登录
	 * @param UserName
	 * @param UserPassWord
	 * @param response
	 * @throws Exception
	 * RequestMapping一个用来处理请求地址映射的注解，可用于类或方法上。用于类上，表示类中的所有响应请求的方法都是以该地址作为父路径。
	 * responsebody表示该方法的返回结果直接写入HTTP response body中 一般在异步获取数据时使用,在使用
	 */
	@RequestMapping(value = "/Login.do", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Login(String UserName, String UserPassWord, HttpServletResponse response) throws Exception {
		try {
			User user = userService.selectByUserLogin(UserName, UserPassWord);
			if (user != null) {
				if(user.getUserstate()==true)	
				{
					Result result = new Result(user);
					Json.toJson(result, response);
					
				}
				else
				{
					Json.toJson(new Result(false,"该账号已禁用"), response);
					return;
				}
			} 
			else 
			{
				Json.toJson(new Result(false,"账号或密码错误"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 查询
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Select.do", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Select(HttpServletRequest request,HttpServletResponse response) throws Exception {
		try {
			List<User> users = userService.SelectUsers();
			if (users != null && users.size() != 0) {
				Json.toJson(users, response);
			} else {
				Json.toJson(new Result(false,"用户不存在"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 删除
	 * @param ID
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Delete.do",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Delete(String ID,HttpServletResponse response) throws Exception {
		try {
			int i = userService.deleteByPrimaryKey(ID);
			if (i > 0) {
				Result result = new Result(true,"删除成功");
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"删除失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	@RequestMapping(value = "/Insert.do",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Insert(User user,HttpServletRequest request,HttpServletResponse response) throws Exception {
		try {
			user.setId(UUIDTool.getUUID());
			Cookie[] cookies = request.getCookies();//根据请求数据，找到cookie数组

	        if (null==cookies) {
	        	Json.toJson(new Result(false,"插入失败"), response);
	        } else {
	            for(Cookie cookie : cookies){
	                if(cookie.getName().equals("userid")){
	                	user.setCreateuserid(cookie.getValue());
	                }
	                if(cookie.getName().equals("username")){ 
	                	user.setCreateusername(URLDecoder.decode(cookie.getValue(), "UTF-8"));
	                }
	            }
	        }
			user.setCreatetime(new Date());
			int i = userService.insert(user);
			if (i > 0) {
				Result result = new Result(true,"插入成功",user);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"插入失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}

	@RequestMapping(value = "/Update.do",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Update(User user,HttpServletResponse response) throws Exception {
		try {
			int i = userService.updateByPrimaryKey(user);
			if (i > 0) {
				Result result = new Result(true,"更新成功",user);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"更新失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	@RequestMapping(value = "/PassWord.do",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void PassWord(String oldPassWord,String newPassWord,HttpServletRequest request,HttpServletResponse response) throws Exception {
		try {
			int i = 0;
			Cookie[] cookies = request.getCookies();//根据请求数据，找到cookie数组

	        if (null==cookies) {
	        	Json.toJson(new Result(false,"更新失败"), response);
	        } else {
	            for(Cookie cookie : cookies){
	                if(cookie.getName().equals("id")){
	                	i = userService.updateByUserModifyPass(cookie.getValue(), oldPassWord,newPassWord);
	                }
	            }
	        }
			if (i > 0) {
				Result result = new Result(true,"更新成功");
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"更新失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	

}
