package com.advance.controller;

import java.net.URLDecoder;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.advance.Util.Json;
import com.advance.Util.Result;
import com.advance.Util.UUIDTool;
import com.advance.model.Class;
import com.advance.model.Curriculum;
import com.advance.model.Major;
import com.advance.model.Schoolroll;
import com.advance.service.ClassService;
import com.advance.service.CurriculumService;
import com.advance.service.MajorService;
import com.advance.service.SchoolrollService;

@Controller
@RequestMapping("/Major")
public class MajorController {

	@Resource
	private MajorService MajorService;
	@Resource
	private ClassService classservice;
	@Resource
	private SchoolrollService schoolrollservice;
	@Resource
	private CurriculumService curriculumservice;
	/**
	 * 查询
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Select.do", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Select(HttpServletResponse response) throws Exception {
		try {
			List<Major> Majors = MajorService.SelectMajors();
			if (Majors != null && Majors.size() != 0) {
				Json.toJson(Majors, response);
			} else {
				Json.toJson(new Result(false,"数据不存在"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 删除
	 * @param ID
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Delete.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Delete(String ID,HttpServletResponse response) throws Exception {
		try {
			
           List<Class> classs = classservice.SelectClasssByMajorID(ID);
			
			if(classs.size()!=0)
			{
				Json.toJson(new Result(false,"该专业已被班级调用，不可删除"), response);
				return;
			}
			
           List<Schoolroll> schoolroll = schoolrollservice.SelectSchoolrollsByMajorID(ID);
			
			if(schoolroll.size()!=0)
			{
				Json.toJson(new Result(false,"该专业已被学籍调用，不可删除"), response);
				return;
			}
			
			List<Curriculum> curriculum=curriculumservice.SelectCurriculumsByMajorID(ID);
			
			if(curriculum.size()!=0)
			{
				Json.toJson(new Result(false,"该专业已被课程调用，不可删除"), response);
				return;
			}
			
			int i = MajorService.deleteByPrimaryKey(ID);
			if (i > 0) {
				Result result = new Result(true,"删除成功");
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"删除失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 插入
	 * @param Major
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Insert.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Insert(Major Major,HttpServletRequest request,HttpServletResponse response) throws Exception {
		try {
			Major.setId(UUIDTool.getUUID());
			Cookie[] cookies = request.getCookies();//根据请求数据，找到cookie数组

	        if (null==cookies) {
	        	Json.toJson(new Result(false,"插入失败"), response);
	        } else {
	            for(Cookie cookie : cookies){
	                if(cookie.getName().equals("userid")){
	                	Major.setCreateuserid(cookie.getValue());
	                }
	                if(cookie.getName().equals("username")){ 
	                	Major.setCreateusername(URLDecoder.decode(cookie.getValue(), "UTF-8"));
	                }
	            }
	        }
			Major.setCreatetime(new Date());
			int i = MajorService.insert(Major);
			if (i > 0) {
				Result result = new Result(true,"插入成功",Major);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"插入失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 更新
	 * @param Major
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Update.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Update(Major Major,HttpServletResponse response) throws Exception {
		try {
			int i = MajorService.updateByPrimaryKey(Major);
			if (i > 0) {
				Result result = new Result(true,"更新成功",Major);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"更新失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	

}
