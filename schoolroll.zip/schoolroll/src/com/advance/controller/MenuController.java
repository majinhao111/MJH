package com.advance.controller;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.advance.Util.Json;
import com.advance.Util.Result;
import com.advance.model.Menu;
import com.advance.service.MenuService;

@Controller
@RequestMapping("/Menu")
public class MenuController {
	
	@Resource
	private MenuService menuService;
	
	@RequestMapping(value = "/GetMenu.do", method = RequestMethod.POST,produces="text/html;charset=UTF-8")
	@ResponseBody
	public void GetMenu(String Type,HttpServletResponse response) throws Exception{
		try
		{
			List<Menu> menu  = menuService.selectByType(Type);
			if(menu!=null &&menu.size()!=0)
			{ 
		        Result result = new Result(menu);
		        Json.toJson(result,response); 
			}
			else
			{ 
				Json.toJson(new Result(false,"菜单不存在"),response);  
				return;
			}
		}
		catch(Exception ex)
		{
			Json.toJson(new Result(false,ex.getMessage()),response);  
		}
		
	}
	
}
