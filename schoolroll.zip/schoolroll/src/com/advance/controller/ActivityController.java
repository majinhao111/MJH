package com.advance.controller;

import java.net.URLDecoder;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.advance.Util.Json;
import com.advance.Util.Result;
import com.advance.Util.UUIDTool;
import com.advance.model.Activity;
import com.advance.model.Teacher;
import com.advance.service.ActivityService;
import com.advance.service.TeacherService;

@Controller
@RequestMapping("/Activity")
public class ActivityController {

	@Resource
	private ActivityService activityService;
	@Resource
	private TeacherService teacherservice;
	/**
	 * 查询
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Select.do", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Select(HttpServletResponse response) throws Exception {
		try {
			List<Activity> activitys = activityService.SelectActivitys();
			if (activitys != null && activitys.size() != 0) {
				Json.toJson(activitys, response);
			} else {
				Json.toJson(new Result(false,"数据不存在"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 查询
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/SelectByExamUserID.do", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void SelectByExamUserID(HttpServletRequest request,HttpServletResponse response) throws Exception {
		try {
			
			Cookie[] cookies = request.getCookies();//根据请求数据，找到cookie数组

	        if (null==cookies) {
	        	Json.toJson(new Result(false,"登录状态异常，请重新登录"), response);
	        	return;
	        }
	        
	        String userid=null;
	        for(Cookie cookie : cookies){
                if(cookie.getName().equals("userid")){
                	userid=cookie.getValue();
                }
            }
			List<Activity> activitys = activityService.SelectActivitysByExamUserID(userid);
			
			if (activitys != null && activitys.size() != 0) {
				Json.toJson(activitys, response);
			} else {
				Json.toJson(new Result(false,"数据不存在"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 查询
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/SelectByApplicantID.do", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void SelectByApplicantID(HttpServletRequest request,HttpServletResponse response) throws Exception {
		try {
			
			Cookie[] cookies = request.getCookies();//根据请求数据，找到cookie数组

	        if (null==cookies) {
	        	Json.toJson(new Result(false,"登录状态异常，请重新登录"), response);
	        	return;
	        }
	        
	        String userid=null;
	        for(Cookie cookie : cookies){
                if(cookie.getName().equals("userid")){
                	userid=cookie.getValue();
                }
            }
			List<Activity> activitys = activityService.SelectActivitysByApplicantID(userid);
			
			if (activitys != null && activitys.size() != 0) {
				Json.toJson(activitys, response);
			} else {
				Json.toJson(new Result(false,"数据不存在"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 删除
	 * @param ID
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Delete.do",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Delete(String ID,HttpServletResponse response) throws Exception {
		try {
			int i = activityService.deleteByPrimaryKey(ID);
			if (i > 0) {
				Result result = new Result(true,"删除成功");
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"删除失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 审核
	 * @param ID
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Exam.do",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Exam(String ID,HttpServletResponse response) throws Exception {
		try {
			
			Activity activity=activityService.selectByPrimaryKey(ID);
			if(activity==null)
			{
				Json.toJson(new Result(false,"活动申请不存在，审批失败"), response);
				return;
			}
			
			activity.setActivitystate(true);
			activity.setExamtime(new Date());
			
			int i = activityService.updateByPrimaryKey(activity);
			if (i > 0) {
				Result result = new Result(true,"审批成功");
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"审批失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 插入
	 * @param activity
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Insert.do",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Insert(Activity activity,HttpServletRequest request,HttpServletResponse response) throws Exception {
		try {
			activity.setId(UUIDTool.getUUID());
			activity.setActivitystate(false);
			Cookie[] cookies = request.getCookies();//根据请求数据，找到cookie数组

	        if (null==cookies) {
	        	Json.toJson(new Result(false,"插入失败"), response);
	        } else {
	            for(Cookie cookie : cookies){
	                if(cookie.getName().equals("userid")){
	                	activity.setApplicantid(cookie.getValue());
	                }
	                if(cookie.getName().equals("username")){ 
	                	activity.setApplicantname(URLDecoder.decode(cookie.getValue(), "UTF-8"));
	                }
	            }
	        }
			activity.setApplicanttime(new Date());
			
			Teacher teacher=teacherservice.selectByPrimaryKey(activity.getExamusername());
			
			if(teacher==null)
			{
				Json.toJson(new Result(false,"插入失败"), response);
				return;
			}
	
			activity.setExamuserid(teacher.getTeacherid());
			activity.setExamusername(teacher.getTeachername());
			
			int i = activityService.insert(activity);
			if (i > 0) {
				Result result = new Result(true,"插入成功",activity);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"插入失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 更新
	 * @param activity
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Update.do",method = RequestMethod.POST,produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Update(Activity activity,HttpServletResponse response) throws Exception {
		try {
			int i = activityService.updateByPrimaryKey(activity);
			if (i > 0) {
				Result result = new Result(true,"更新成功",activity);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"更新失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	

}
