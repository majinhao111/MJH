package com.advance.controller;

import java.net.URLDecoder;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.advance.Util.Json;
import com.advance.Util.Result;
import com.advance.Util.UUIDTool;
import com.advance.model.Activity;
import com.advance.model.Class;
import com.advance.model.Schoolroll;
import com.advance.service.ActivityService;
import com.advance.service.ClassService;
import com.advance.service.SchoolrollService;

@Controller
@RequestMapping("/Class")
public class ClassController {

	@Resource
	private ClassService ClassService;
	@Resource
	private SchoolrollService schoolrollservice;
	@Resource
	private ActivityService activityservice;

	/**
	 * 查询
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Select.do", method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Select(HttpServletResponse response) throws Exception {
		try {
			List<Class> Classs = ClassService.SelectClasss();
			if (Classs != null && Classs.size() != 0) {
				Json.toJson(Classs, response);
			} else {
				Json.toJson(new Result(false,"数据不存在"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 删除
	 * @param ID
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Delete.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Delete(String ID,HttpServletResponse response) throws Exception {
		try {
            List<Schoolroll> schoolroll = schoolrollservice.SelectSchoolrollsByClassID(ID);
			
			if(schoolroll.size()!=0)
			{
				Json.toJson(new Result(false,"该班级已被学籍调用，不可删除"), response);
				return;
			}
			
			List<Activity> activity=activityservice.SelectActivitysByClassID(ID);
			
			if(activity.size()!=0)
			{
				Json.toJson(new Result(false,"该班级已被活动调用，不可删除"), response);
				return;
			}
			int i = ClassService.deleteByPrimaryKey(ID);
			if (i > 0) {
				Result result = new Result(true,"删除成功");
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"删除失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 插入
	 * @param Class
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Insert.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Insert(Class Class,HttpServletRequest request,HttpServletResponse response) throws Exception {
		try {
			Class.setId(UUIDTool.getUUID());
			Cookie[] cookies = request.getCookies();//根据请求数据，找到cookie数组

	        if (null==cookies) {
	        	Json.toJson(new Result(false,"插入失败"), response);
	        } else {
	            for(Cookie cookie : cookies){
	                if(cookie.getName().equals("userid")){
	                	Class.setCreateuserid(cookie.getValue());
	                }
	                if(cookie.getName().equals("username")){ 
	                	Class.setCreateusername(URLDecoder.decode(cookie.getValue(), "UTF-8"));
	                }
	            }
	        }
			Class.setCreatetime(new Date());
			int i = ClassService.insert(Class);
			if (i > 0) {
				Result result = new Result(true,"插入成功",Class);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"插入失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 更新
	 * @param Class
	 * @param response
	 * @throws Exception
	 */
	@RequestMapping(value = "/Update.do",method = RequestMethod.POST, produces = "text/html;charset=UTF-8")
	@ResponseBody
	public void Update(Class Class,HttpServletResponse response) throws Exception {
		try {
			int i = ClassService.updateByPrimaryKey(Class);
			if (i > 0) {
				Result result = new Result(true,"更新成功",Class);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"更新失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	

}
