package com.advance.controller;

import java.net.URLDecoder;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.advance.Util.Json;
import com.advance.Util.Result;
import com.advance.Util.UUIDTool;
import com.advance.model.Class;
import com.advance.model.College;
import com.advance.model.Curriculum;
import com.advance.model.Major;
import com.advance.model.Schoolroll;
import com.advance.model.Teacher;
import com.advance.service.ClassService;
import com.advance.service.CollegeService;
import com.advance.service.CurriculumService;
import com.advance.service.MajorService;
import com.advance.service.SchoolrollService;
import com.advance.service.TeacherService;

@Controller
@RequestMapping("/College")
public class CollegeController {
	@Resource
	private CollegeService collegeservice;
	@Resource
	private MajorService majorservice;
	@Resource
	private ClassService classservice;
	@Resource
	private TeacherService teatherservice;
	@Resource
	private SchoolrollService schoolrollservice;
	@Resource
	private CurriculumService curriculumservice;
	/**
	 * 查询学院
	 */
	@RequestMapping(value = "/Select.do", method = RequestMethod.POST,produces="text/html;charset=UTF-8")
	@ResponseBody
	public void Select(HttpServletResponse response) throws Exception {
		try {
			List<College> college = collegeservice.SelectColleges();
			if (college != null && college.size() != 0) {
				Json.toJson(college, response);
			} else {
				Json.toJson(new Result(false,"没有要查找的数据"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	/**
	 * 插入
	 * @param Class
	 */
	@RequestMapping(value = "/Insert.do",method = RequestMethod.POST,produces="text/html;charset=UTF-8")
	@ResponseBody
	public void Insert(College college,HttpServletRequest request,HttpServletResponse response) throws Exception {
		try {
			college.setId(UUIDTool.getUUID());
			Cookie[] cookies = request.getCookies();//根据请求数据，找到cookie数组

	        if (null==cookies) {
	        	Json.toJson(new Result(false,"插入失败"), response);
	        } else {
	            for(Cookie cookie : cookies){
	                if(cookie.getName().equals("userid")){
	                	college.setCreateuserid(cookie.getValue());
	                }
	                if(cookie.getName().equals("username")){ 
	                	college.setCreateusername(URLDecoder.decode(cookie.getValue(), "UTF-8"));
	                }
	            }
	        }
			college.setCreatetime(new Date());
			int i = collegeservice.insert(college);
			if (i > 0) {
				Result result = new Result(true,"插入成功",college);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"插入失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	/**
	 * 删除学院信息
	 */
	@RequestMapping(value = "/Delete.do",method = RequestMethod.POST,produces="text/html;charset=UTF-8")
	@ResponseBody
	public void Delete(String ID,HttpServletResponse response) throws Exception {
		try {
			
			List<Major> major=majorservice.SelectMajorsByCollegeID(ID);
				
			if(major.size()!=0)
			{
				Json.toJson(new Result(false,"该学院已被专业调用，不可删除"), response);
				return;
			}
			
			List<Class> classs = classservice.SelectClasssByCollegeID(ID);
			
			if(classs.size()!=0)
			{
				Json.toJson(new Result(false,"该学院已被班级调用，不可删除"), response);
				return;
			}
			
			List<Teacher> teacher = teatherservice.SelectTeachersByCollegeID(ID);
			
			if(teacher.size()!=0)
			{
				Json.toJson(new Result(false,"该学院已被教师调用，不可删除"), response);
				return;
			}
			
            List<Schoolroll> schoolroll = schoolrollservice.SelectSchoolrollsByCollegeID(ID);
			
			if(schoolroll.size()!=0)
			{
				Json.toJson(new Result(false,"该学院已被学籍调用，不可删除"), response);
				return;
			}
			
			List<Curriculum> curriculum=curriculumservice.SelectCurriculumsByCollegeID(ID);
			
			if(curriculum.size()!=0)
			{
				Json.toJson(new Result(false,"该学院已被课程调用，不可删除"), response);
				return;
			}
			
			int i = collegeservice.deleteByPrimaryKey(ID);
			if (i > 0) {
				Result result = new Result(true,"删除成功");
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"删除失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}

	}
	
	@RequestMapping(value = "/Update.do",method = RequestMethod.POST,produces="text/html;charset=UTF-8")
	@ResponseBody
	public void Update(College college,HttpServletResponse response) throws Exception {
		try {
			int i = collegeservice.updateByPrimaryKey(college);
			if (i > 0) {
				Result result = new Result(true,"更新成功",college);
				Json.toJson(result, response);
			} else {
				Json.toJson(new Result(false,"更新失败"), response);
				return;
			}
		} catch (Exception ex) {
			Json.toJson(new Result(false, "请求异常"), response);
		}
	}

}
