package com.advance.model;

import java.util.Date;

public class College {
    private String id;

    private String collegeid;

    private String collegename;

    private Integer collegenumber;

    private String collegedean;

    private String createuserid;

    private String createusername;

    private Date createtime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getCollegeid() {
        return collegeid;
    }

    public void setCollegeid(String collegeid) {
        this.collegeid = collegeid == null ? null : collegeid.trim();
    }

    public String getCollegename() {
        return collegename;
    }

    public void setCollegename(String collegename) {
        this.collegename = collegename == null ? null : collegename.trim();
    }

    public Integer getCollegenumber() {
        return collegenumber;
    }

    public void setCollegenumber(Integer collegenumber) {
        this.collegenumber = collegenumber;
    }

    public String getCollegedean() {
        return collegedean;
    }

    public void setCollegedean(String collegedean) {
        this.collegedean = collegedean == null ? null : collegedean.trim();
    }

    public String getCreateuserid() {
        return createuserid;
    }

    public void setCreateuserid(String createuserid) {
        this.createuserid = createuserid == null ? null : createuserid.trim();
    }

    public String getCreateusername() {
        return createusername;
    }

    public void setCreateusername(String createusername) {
        this.createusername = createusername == null ? null : createusername.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }
}