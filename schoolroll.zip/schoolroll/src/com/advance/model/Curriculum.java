package com.advance.model;

import java.math.BigDecimal;
import java.util.Date;

public class Curriculum {
    private String id;

    private String curriculumid;

    private String curriculumname;

    private String curriculumdescribe;

    private BigDecimal curriculumcredit;

    private BigDecimal curriculumfraction;

    private String collegeid;

    private String majorid;

    private String createuserid;

    private String createusername;

    private Date createtime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getCurriculumid() {
        return curriculumid;
    }

    public void setCurriculumid(String curriculumid) {
        this.curriculumid = curriculumid == null ? null : curriculumid.trim();
    }

    public String getCurriculumname() {
        return curriculumname;
    }

    public void setCurriculumname(String curriculumname) {
        this.curriculumname = curriculumname == null ? null : curriculumname.trim();
    }

    public String getCurriculumdescribe() {
        return curriculumdescribe;
    }

    public void setCurriculumdescribe(String curriculumdescribe) {
        this.curriculumdescribe = curriculumdescribe == null ? null : curriculumdescribe.trim();
    }

    public BigDecimal getCurriculumcredit() {
        return curriculumcredit;
    }

    public void setCurriculumcredit(BigDecimal curriculumcredit) {
        this.curriculumcredit = curriculumcredit;
    }

    public BigDecimal getCurriculumfraction() {
        return curriculumfraction;
    }

    public void setCurriculumfraction(BigDecimal curriculumfraction) {
        this.curriculumfraction = curriculumfraction;
    }

    public String getCollegeid() {
        return collegeid;
    }

    public void setCollegeid(String collegeid) {
        this.collegeid = collegeid == null ? null : collegeid.trim();
    }

    public String getMajorid() {
        return majorid;
    }

    public void setMajorid(String majorid) {
        this.majorid = majorid == null ? null : majorid.trim();
    }

    public String getCreateuserid() {
        return createuserid;
    }

    public void setCreateuserid(String createuserid) {
        this.createuserid = createuserid == null ? null : createuserid.trim();
    }

    public String getCreateusername() {
        return createusername;
    }

    public void setCreateusername(String createusername) {
        this.createusername = createusername == null ? null : createusername.trim();
    }

    public Date getCreatetime() {
        return createtime;
    }

    public void setCreatetime(Date createtime) {
        this.createtime = createtime;
    }
}