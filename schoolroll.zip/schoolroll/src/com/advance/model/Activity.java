package com.advance.model;

import java.util.Date;

public class Activity {
    private String id;

    private String activityid;

    private String activityname;

    private String classid;

    private String applicantid;

    private String applicantname;

    private Date applicanttime;

    private Boolean activitystate;

    private String examuserid;

    private String examusername;

    private Date examtime;

    private String activitydescribe;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id == null ? null : id.trim();
    }

    public String getActivityid() {
        return activityid;
    }

    public void setActivityid(String activityid) {
        this.activityid = activityid == null ? null : activityid.trim();
    }

    public String getActivityname() {
        return activityname;
    }

    public void setActivityname(String activityname) {
        this.activityname = activityname == null ? null : activityname.trim();
    }

    public String getClassid() {
        return classid;
    }

    public void setClassid(String classid) {
        this.classid = classid == null ? null : classid.trim();
    }

    public String getApplicantid() {
        return applicantid;
    }

    public void setApplicantid(String applicantid) {
        this.applicantid = applicantid == null ? null : applicantid.trim();
    }

    public String getApplicantname() {
        return applicantname;
    }

    public void setApplicantname(String applicantname) {
        this.applicantname = applicantname == null ? null : applicantname.trim();
    }

    public Date getApplicanttime() {
        return applicanttime;
    }

    public void setApplicanttime(Date applicanttime) {
        this.applicanttime = applicanttime;
    }

    public Boolean getActivitystate() {
        return activitystate;
    }

    public void setActivitystate(Boolean activitystate) {
        this.activitystate = activitystate;
    }

    public String getExamuserid() {
        return examuserid;
    }

    public void setExamuserid(String examuserid) {
        this.examuserid = examuserid == null ? null : examuserid.trim();
    }

    public String getExamusername() {
        return examusername;
    }

    public void setExamusername(String examusername) {
        this.examusername = examusername == null ? null : examusername.trim();
    }

    public Date getExamtime() {
        return examtime;
    }

    public void setExamtime(Date examtime) {
        this.examtime = examtime;
    }

    public String getActivitydescribe() {
        return activitydescribe;
    }

    public void setActivitydescribe(String activitydescribe) {
        this.activitydescribe = activitydescribe == null ? null : activitydescribe.trim();
    }
}