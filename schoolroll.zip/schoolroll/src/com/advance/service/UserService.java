package com.advance.service;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.advance.model.User;

public interface UserService {
	int deleteByPrimaryKey(String id);

    int insert(User record);

    int insertSelective(User record);

    User selectByPrimaryKey(String id);
    
    User selectByUserLogin(String username,String userpassword);
    
    //User selectByUserModifyPass(@Param("id")String id,@Param("userpassword")String userpassword);
    
    int updateByUserModifyPass(@Param("id")String id,@Param("userpassword")String userpassword,@Param("newuserpassword")String newuserpassword);

    int updateByPrimaryKeySelective(User record);

    int updateByPrimaryKey(User record);
    
    List<User> SelectUsers();
}
