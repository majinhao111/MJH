package com.advance.service;

import java.util.List;

import com.advance.model.Activity;

public interface ActivityService {
	int deleteByPrimaryKey(String id);

    int insert(Activity record);

    int insertSelective(Activity record);

    Activity selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Activity record);

    int updateByPrimaryKeyWithBLOBs(Activity record);

    int updateByPrimaryKey(Activity record);
    
    List<Activity> SelectActivitys();
    
    List<Activity> SelectActivitysByClassID(String classid);
    
    List<Activity> SelectActivitysByExamUserID(String examuserid);
    
    List<Activity> SelectActivitysByApplicantID(String applicantid);
}
