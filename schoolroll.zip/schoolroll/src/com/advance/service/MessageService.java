package com.advance.service;

import java.util.List;

import com.advance.model.Message;
public interface MessageService {
	int deleteByPrimaryKey(String id);

    int insert(Message record);

    int insertSelective(Message record);

    Message selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Message record);

    int updateByPrimaryKeyWithBLOBs(Message record);

    int updateByPrimaryKey(Message record);
    
    List<Message> SelectMessages();
    
    List<Message> SelectMessagesBySourceID(String sourceid);
    
    int DeleteBySourceID(String sourceid);
}
