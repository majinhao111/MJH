package com.advance.service;

import java.util.List;

import com.advance.model.Curriculum;
public interface CurriculumService {
	int deleteByPrimaryKey(String id);

    int insert(Curriculum record);

    int insertSelective(Curriculum record);

    Curriculum selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Curriculum record);

    int updateByPrimaryKey(Curriculum record);
    
    List<Curriculum> SelectCurriculums();
    
    List<Curriculum> SelectCurriculumsByCollegeID(String collegeid);
    
    List<Curriculum> SelectCurriculumsByMajorID(String majorid);
}
