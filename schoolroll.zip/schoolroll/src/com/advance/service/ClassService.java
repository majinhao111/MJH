package com.advance.service;

import java.util.List;

import com.advance.model.Class;

public interface ClassService {
	int deleteByPrimaryKey(String id);

    int insert(Class record);

    int insertSelective(Class record);

    Class selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Class record);

    int updateByPrimaryKey(Class record);
    
    List<Class> SelectClasss();
    
    List<Class> SelectClasssByCollegeID(String collegeid);
    
    List<Class> SelectClasssByMajorID(String majorid);
    
    com.advance.model.Class SelectByClassName(String classname);
}
