package com.advance.service;

import java.util.List;

import com.advance.model.Schoolroll;
public interface SchoolrollService {
	 int deleteByPrimaryKey(String id);

	    int insert(Schoolroll record);

	    int insertSelective(Schoolroll record);

	    Schoolroll selectByPrimaryKey(String id);

	    int updateByPrimaryKeySelective(Schoolroll record);

	    int updateByPrimaryKey(Schoolroll record);
	    
	    List<Schoolroll> SelectSchoolrolls();
	    
	    List<Schoolroll> SelectSchoolrollsByCollegeID(String collegeid);
	    
	    List<Schoolroll> SelectSchoolrollsByMajorID(String majorid);
	    
	    List<Schoolroll> SelectSchoolrollsByClassID(String classid);
	    
	    Schoolroll SelectSchoolrollsBySchoolRollID(String schooltollid);
}
