package com.advance.Util;

/** 
 * 数据返回实体 
 * @author Administrator 
 * 
 */  
public class Result {  
  
    private Boolean Status;//状态  
    private String massege;//消息  
    private Object result;//数据对象  
      
    /** 
     * 无参构造器 
     */  
    public Result(){  
        super();  
    }  
    
    /** 
     * 只返回 数据对象 
     * @param statu 
     * @param code 
     * @param massege 
     */  
    public Result(Object result){  
        super(); 
        this.Status = true;
        this.result=result;   
    } 
    
    /** 
     * 只返回状态， 消息
     * @param statu 
     * @param massege 
     */  
    public Result(Boolean Status,String massege){  
        super(); 
        this.Status=Status;
        this.massege=massege;   
    }  
      
    /** 
     * 只返回状态，数据对象 
     * @param statu 
     * @param code 
     * @param object 
     */  
    public Result(Boolean Status,Object result){  
        super();  
        this.Status=Status;  
        this.result=result;  
    }  
      
    /** 
     * 返回全部信息即状态，消息，数据对象 
     * @param statu 
     * @param code 
     * @param massege 
     * @param result 
     */  
    public Result(Boolean Status, String massege, Object result){  
        super();  
        this.Status=Status; 
        this.massege=massege;  
        this.result=result;  
    }  
    
    public Boolean getStatus() {
		return Status;
	}

	public void setStatus(Boolean status) {
		Status = status;
	}

	public String getMassege() {  
        return massege;  
    }  
  
    public void setMassege(String massege) {  
        this.massege = massege;  
    }  
  
    public Object getResult() {  
        return result;  
    }  
  
    public void setResult(Object result) {  
        this.result = result;  
    }  

}  
