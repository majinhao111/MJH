package com.advance.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.advance.model.User;

public interface UserMapper {
    int deleteByPrimaryKey(String id);

    int insert(User record);

    int insertSelective(User record);

    User selectByPrimaryKey(String id);
    
    User selectByUserLogin(@Param("username")String username,@Param("userpassword")String userpassword);
    
    int updateByUserModifyPass(@Param("id")String id,@Param("userpassword")String userpassword,@Param("newuserpassword")String newuserpassword);

    int updateByPrimaryKeySelective(User record);

    int updateByPrimaryKey(User record);
    
    List<User> SelectUsers();
}