package com.advance.mapper;

import java.util.List;

import com.advance.model.Teacher;

public interface TeacherMapper {
    int deleteByPrimaryKey(String id);

    int insert(Teacher record);

    int insertSelective(Teacher record);

    Teacher selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Teacher record);

    int updateByPrimaryKey(Teacher record);
    
    List<Teacher> SelectTeachers();
    
    List<Teacher> SelectTeachersByCollegeID(String collegeid);
}