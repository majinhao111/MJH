package com.advance.mapper;

import java.util.List;

import com.advance.model.Achievement;

public interface AchievementMapper {
    int deleteByPrimaryKey(String id);

    int insert(Achievement record);

    int insertSelective(Achievement record);

    Achievement selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Achievement record);

    int updateByPrimaryKey(Achievement record);
    
    List<Achievement> SelectAchievements();
    
    List<Achievement> SelectAchievementsBySchoolRollID(String schoolrollid);
    
    List<Achievement> SelectAchievementsByCurriculumID(String curriculumid);
    
    List<Achievement> SelectAchievementsByClassID(String classid);
}