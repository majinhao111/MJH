package com.advance.mapper;

import java.util.List;

import com.advance.model.College;


public interface CollegeMapper {
    int deleteByPrimaryKey(String id);

    int insert(College record);

    int insertSelective(College record);

    College selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(College record);

    int updateByPrimaryKey(College record);
    
    List<College> SelectColleges();
    
    College SelectByCollegeName(String collegename);
    
}