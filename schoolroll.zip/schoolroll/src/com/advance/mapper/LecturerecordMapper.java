package com.advance.mapper;

import java.util.List;

import com.advance.model.Lecturerecord;

public interface LecturerecordMapper {
    int deleteByPrimaryKey(String id);

    int insert(Lecturerecord record);

    int insertSelective(Lecturerecord record);

    Lecturerecord selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Lecturerecord record);

    int updateByPrimaryKey(Lecturerecord record);
    
    List<Lecturerecord> SelectLecturerecords();
}