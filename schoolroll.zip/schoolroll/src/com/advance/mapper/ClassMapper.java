package com.advance.mapper;

import java.util.List;

import com.advance.model.Class;

public interface ClassMapper {
    int deleteByPrimaryKey(String id);

    int insert(com.advance.model.Class record);

    int insertSelective(com.advance.model.Class record);

    com.advance.model.Class selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(com.advance.model.Class record);

    int updateByPrimaryKey(com.advance.model.Class record);
    
    List<Class> SelectClasss();
    
    List<Class> SelectClasssByCollegeID(String collegeid);
    
    List<Class> SelectClasssByMajorID(String majorid);
    
    com.advance.model.Class SelectByClassName(String classname);
}