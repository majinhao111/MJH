package com.advance.mapper;

import java.util.List;

import com.advance.model.Major;

public interface MajorMapper{
    int deleteByPrimaryKey(String id);

    int insert(Major record);

    int insertSelective(Major record);

    Major selectByPrimaryKey(String id);

    int updateByPrimaryKeySelective(Major record);

    int updateByPrimaryKey(Major record);
    
    List<Major> SelectMajors();
    
    List<Major> SelectMajorsByCollegeID(String colleged);
    
    Major SelectByMajorName(String majorname);
}