package com.advance.serviceImp;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.advance.mapper.ClassMapper;
import com.advance.model.Class;
import com.advance.service.ClassService;
/**
 * @author advance
 */
@Service
public class ClassServiceImp implements ClassService {
	@Resource
	private ClassMapper classMapper;
	@Override
	public int deleteByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return classMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int insert(Class record) {
		// TODO Auto-generated method stub
		return classMapper.insert(record);
	}

	@Override
	public int insertSelective(Class record) {
		// TODO Auto-generated method stub
		return classMapper.insertSelective(record);
	}

	@Override
	public Class selectByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return classMapper.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(Class record) {
		// TODO Auto-generated method stub
		return classMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public int updateByPrimaryKey(Class record) {
		// TODO Auto-generated method stub
		return classMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public List<Class> SelectClasss() {
		// TODO Auto-generated method stub
		return classMapper.SelectClasss();
	}

	@Override
	public List<Class> SelectClasssByCollegeID(String collegeid) {
		// TODO Auto-generated method stub
		return classMapper.SelectClasssByCollegeID(collegeid);
	}

	@Override
	public List<Class> SelectClasssByMajorID(String majorid) {
		// TODO Auto-generated method stub
		return classMapper.SelectClasssByMajorID(majorid);
	}

	@Override
	public Class SelectByClassName(String classname) {
		// TODO Auto-generated method stub
		return classMapper.SelectByClassName(classname);
	}
	
}
