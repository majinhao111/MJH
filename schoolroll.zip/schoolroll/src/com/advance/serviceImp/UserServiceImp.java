package com.advance.serviceImp;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.advance.mapper.UserMapper;
import com.advance.model.User;
import com.advance.service.UserService;
/**
 * @author advance
 */
@Service
public class UserServiceImp implements UserService {
	
	@Resource
	private UserMapper userMapper;

	@Override
	public int deleteByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return userMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int insert(User record) {
		// TODO Auto-generated method stub
		return userMapper.insert(record);
	}

	@Override
	public int insertSelective(User record) {
		// TODO Auto-generated method stub
		return userMapper.insertSelective(record);
	}

	@Override
	public User selectByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return userMapper.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(User record) {
		// TODO Auto-generated method stub
		return userMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public int updateByPrimaryKey(User record) {
		// TODO Auto-generated method stub
		return userMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public User selectByUserLogin(String username, String userpassword) {
		// TODO Auto-generated method stub
		return userMapper.selectByUserLogin(username, userpassword);
	}

	@Override
	public List<User> SelectUsers() {
		// TODO Auto-generated method stub
		return userMapper.SelectUsers();
	}

	@Override
	public int updateByUserModifyPass(String id, String userpassword, String newuserpassword) {
		// TODO Auto-generated method stub
		return userMapper.updateByUserModifyPass(id, userpassword, newuserpassword);
	}

//	@Override
//	public User selectByUserModifyPass(String id, String userpassword) {
//		// TODO Auto-generated method stub
//		return userMapper.selectByUserModifyPass(id, userpassword);
//	}

}
