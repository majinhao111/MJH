package com.advance.serviceImp;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.advance.mapper.CollegeMapper;
import com.advance.model.College;
import com.advance.service.CollegeService;
/**
 * @author advance
 */
@Service
public class CollegeServiceImp implements CollegeService {

	@Resource
	private CollegeMapper collegeMapper;
	@Override
	public int deleteByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return collegeMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int insert(College record) {
		// TODO Auto-generated method stub
		return collegeMapper.insert(record);
	}

	@Override
	public int insertSelective(College record) {
		// TODO Auto-generated method stub
		return collegeMapper.insertSelective(record);
	}

	@Override
	public College selectByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return collegeMapper.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(College record) {
		// TODO Auto-generated method stub
		return collegeMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public int updateByPrimaryKey(College record) {
		// TODO Auto-generated method stub
		return collegeMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public List<College> SelectColleges() {
		// TODO Auto-generated method stub
		return collegeMapper.SelectColleges();
	}

	@Override
	public College SelectByCollegeName(String collegename) {
		// TODO Auto-generated method stub
		return collegeMapper.SelectByCollegeName(collegename);
	}
	
	
}
