package com.advance.serviceImp;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.advance.mapper.LecturerecordMapper;
import com.advance.model.Lecturerecord;
import com.advance.service.LecturerecordService;
/**
 * @author advance
 */
@Service
public class LecturerecordServiceImp implements LecturerecordService {

	@Resource
	private LecturerecordMapper lecturerecordMapper;
	
	@Override
	public int deleteByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return lecturerecordMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int insert(Lecturerecord record) {
		// TODO Auto-generated method stub
		return lecturerecordMapper.insert(record);
	}

	@Override
	public int insertSelective(Lecturerecord record) {
		// TODO Auto-generated method stub
		return lecturerecordMapper.insertSelective(record);
	}

	@Override
	public Lecturerecord selectByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return lecturerecordMapper.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(Lecturerecord record) {
		// TODO Auto-generated method stub
		return lecturerecordMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public int updateByPrimaryKey(Lecturerecord record) {
		// TODO Auto-generated method stub
		return lecturerecordMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public List<Lecturerecord> SelectLecturerecords() {
		// TODO Auto-generated method stub
		return lecturerecordMapper.SelectLecturerecords();
	}
}
	
