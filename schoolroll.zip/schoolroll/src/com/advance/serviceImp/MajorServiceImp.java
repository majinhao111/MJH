package com.advance.serviceImp;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.advance.mapper.MajorMapper;
import com.advance.model.Major;
import com.advance.service.MajorService;
/**
 * @author advance
 */
@Service
public class MajorServiceImp implements MajorService {

	@Resource
	private  MajorMapper majorMapper;
	@Override
	public int deleteByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return majorMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int insert(Major record) {
		// TODO Auto-generated method stub
		return majorMapper.insert(record);
	}

	@Override
	public int insertSelective(Major record) {
		// TODO Auto-generated method stub
		return majorMapper.insertSelective(record);
	}

	@Override
	public Major selectByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return majorMapper.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(Major record) {
		// TODO Auto-generated method stub
		return majorMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public int updateByPrimaryKey(Major record) {
		// TODO Auto-generated method stub
		return majorMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public List<Major> SelectMajors() {
		// TODO Auto-generated method stub
		return majorMapper.SelectMajors();
	}

	@Override
	public List<Major> SelectMajorsByCollegeID(String colleged) {
		// TODO Auto-generated method stub
		return majorMapper.SelectMajorsByCollegeID(colleged);
	}

	@Override
	public Major SelectByMajorName(String majorname) {
		// TODO Auto-generated method stub
		return majorMapper.SelectByMajorName(majorname);
	}
	
}
