package com.advance.serviceImp;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.advance.mapper.AchievementMapper;
import com.advance.model.Achievement;
import com.advance.service.AchievementService;
/**
 * @author advance
 */
@Service
public class AchievementServiceImp implements AchievementService {

	@Resource
	private AchievementMapper achievementMapper;
	
	@Override
	public int deleteByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return achievementMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int insert(Achievement record) {
		// TODO Auto-generated method stub
		return achievementMapper.insert(record);
	}

	@Override
	public int insertSelective(Achievement record) {
		// TODO Auto-generated method stub
		return achievementMapper.insertSelective(record);
	}

	@Override
	public Achievement selectByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return achievementMapper.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(Achievement record) {
		// TODO Auto-generated method stub
		return achievementMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public int updateByPrimaryKey(Achievement record) {
		// TODO Auto-generated method stub
		return achievementMapper.updateByPrimaryKeySelective(record);
	}
	
	@Override
	public List<Achievement> SelectAchievements() {
		// TODO Auto-generated method stub
		return achievementMapper.SelectAchievements();
	}

	@Override
	public List<Achievement> SelectAchievementsBySchoolRollID(String schoolrollid) {
		// TODO Auto-generated method stub
		return achievementMapper.SelectAchievementsBySchoolRollID(schoolrollid);
	}

	@Override
	public List<Achievement> SelectAchievementsByCurriculumID(String curriculumid) {
		// TODO Auto-generated method stub
		return achievementMapper.SelectAchievementsByCurriculumID(curriculumid);
	}
	
	@Override
	public List<Achievement> SelectAchievementsByClassID(String classid) {
		// TODO Auto-generated method stub
		return achievementMapper.SelectAchievementsByClassID(classid);
	}
	
}
