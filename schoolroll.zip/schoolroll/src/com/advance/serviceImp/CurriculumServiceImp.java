package com.advance.serviceImp;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.advance.mapper.CurriculumMapper;
import com.advance.model.Curriculum;
import com.advance.service.CurriculumService;
/**
 * @author advance
 */
@Service
public class CurriculumServiceImp implements CurriculumService {

	@Resource
	private CurriculumMapper curriculumMapper;
	
	@Override
	public int deleteByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return curriculumMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int insert(Curriculum record) {
		// TODO Auto-generated method stub
		return curriculumMapper.insert(record);
	}

	@Override
	public int insertSelective(Curriculum record) {
		// TODO Auto-generated method stub
		return curriculumMapper.insertSelective(record);
	}

	@Override
	public Curriculum selectByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return curriculumMapper.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(Curriculum record) {
		// TODO Auto-generated method stub
		return curriculumMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public int updateByPrimaryKey(Curriculum record) {
		// TODO Auto-generated method stub
		return curriculumMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public List<Curriculum> SelectCurriculums() {
		// TODO Auto-generated method stub
		return curriculumMapper.SelectCurriculums();
	}

	@Override
	public List<Curriculum> SelectCurriculumsByCollegeID(String collegeid) {
		// TODO Auto-generated method stub
		return curriculumMapper.SelectCurriculumsByCollegeID(collegeid);
	}

	@Override
	public List<Curriculum> SelectCurriculumsByMajorID(String majorid) {
		// TODO Auto-generated method stub
		return curriculumMapper.SelectCurriculumsByMajorID(majorid);
	}

	
}
