package com.advance.serviceImp;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.advance.mapper.SchoolrollMapper;
import com.advance.model.Schoolroll;
import com.advance.service.SchoolrollService;
/**
 * @author advance
 */
@Service
public class SchoolrollServiceImp implements SchoolrollService {

	@Resource
	private SchoolrollMapper schoolrollMapper;
	@Override
	public int deleteByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return schoolrollMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int insert(Schoolroll record) {
		// TODO Auto-generated method stub
		return schoolrollMapper.insert(record);
	}

	@Override
	public int insertSelective(Schoolroll record) {
		// TODO Auto-generated method stub
		return schoolrollMapper.insertSelective(record);
	}

	@Override
	public Schoolroll selectByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return schoolrollMapper.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(Schoolroll record) {
		// TODO Auto-generated method stub
		return schoolrollMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public int updateByPrimaryKey(Schoolroll record) {
		// TODO Auto-generated method stub
		return schoolrollMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public List<Schoolroll> SelectSchoolrolls() {
		// TODO Auto-generated method stub
		return schoolrollMapper.SelectSchoolrolls();
	}

	@Override
	public List<Schoolroll> SelectSchoolrollsByCollegeID(String collegeid) {
		// TODO Auto-generated method stub
		return schoolrollMapper.SelectSchoolrollsByCollegeID(collegeid);
	}

	@Override
	public List<Schoolroll> SelectSchoolrollsByMajorID(String majorid) {
		// TODO Auto-generated method stub
		return schoolrollMapper.SelectSchoolrollsByMajorID(majorid);
	}

	@Override
	public List<Schoolroll> SelectSchoolrollsByClassID(String classid) {
		// TODO Auto-generated method stub
		return schoolrollMapper.SelectSchoolrollsByClassID(classid);
	}

	@Override
	public Schoolroll SelectSchoolrollsBySchoolRollID(String schooltollid) {
		// TODO Auto-generated method stub
		return schoolrollMapper.SelectSchoolrollsBySchoolRollID(schooltollid);
	}
	
	
}
