package com.advance.serviceImp;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.advance.mapper.TeacherMapper;
import com.advance.model.Teacher;
import com.advance.service.TeacherService;
/**
 * @author advance
 */
@Service
public class TeacherServiceImp implements TeacherService{

	@Resource
	private TeacherMapper teacherMapper;
	@Override
	public int deleteByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return teacherMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int insert(Teacher record) {
		// TODO Auto-generated method stub
		return teacherMapper.insert(record);
	}

	@Override
	public int insertSelective(Teacher record) {
		// TODO Auto-generated method stub
		return teacherMapper.insertSelective(record);
	}

	@Override
	public Teacher selectByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return teacherMapper.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(Teacher record) {
		// TODO Auto-generated method stub
		return teacherMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public int updateByPrimaryKey(Teacher record) {
		// TODO Auto-generated method stub
		return teacherMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public List<Teacher> SelectTeachers() {
		// TODO Auto-generated method stub
		return teacherMapper.SelectTeachers();
	}

	@Override
	public List<Teacher> SelectTeachersByCollegeID(String collegeid) {
		// TODO Auto-generated method stub
		return teacherMapper.SelectTeachersByCollegeID(collegeid);
	}
	
}
