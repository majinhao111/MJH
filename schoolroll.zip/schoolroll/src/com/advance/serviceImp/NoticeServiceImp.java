package com.advance.serviceImp;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.advance.mapper.NoticeMapper;
import com.advance.model.Notice;
import com.advance.service.NoticeService;
/**
 * @author advance
 */
@Service
public class NoticeServiceImp implements NoticeService {

	@Resource
	private  NoticeMapper noticeMapper;
	
	@Override
	public int deleteByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return noticeMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int insert(Notice record) {
		// TODO Auto-generated method stub
		return noticeMapper.insert(record);
	}

	@Override
	public int insertSelective(Notice record) {
		// TODO Auto-generated method stub
		return noticeMapper.insertSelective(record);
	}

	@Override
	public Notice selectByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return noticeMapper.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(Notice record) {
		// TODO Auto-generated method stub
		return noticeMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public int updateByPrimaryKeyWithBLOBs(Notice record) {
		// TODO Auto-generated method stub
		return noticeMapper.updateByPrimaryKeyWithBLOBs(record);
	}

	@Override
	public int updateByPrimaryKey(Notice record) {
		// TODO Auto-generated method stub
		return noticeMapper.updateByPrimaryKey(record);
	}

	@Override
	public List<Notice> selectNotices() {
		// TODO Auto-generated method stub
		return noticeMapper.selectNotices();
	}
	
}
