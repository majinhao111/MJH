package com.advance.serviceImp;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.advance.mapper.MessageMapper;
import com.advance.model.Message;
import com.advance.service.MessageService;
/**
 * @author advance
 */
@Service
public class MessageServiceImp implements MessageService {

	@Resource
	private MessageMapper messageMapper;
	@Override
	public int deleteByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return messageMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int insert(Message record) {
		// TODO Auto-generated method stub
		return messageMapper.insert(record);
	}

	@Override
	public int insertSelective(Message record) {
		// TODO Auto-generated method stub
		return messageMapper.insertSelective(record);
	}

	@Override
	public Message selectByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return messageMapper.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(Message record) {
		// TODO Auto-generated method stub
		return messageMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public int updateByPrimaryKeyWithBLOBs(Message record) {
		// TODO Auto-generated method stub
		return messageMapper.updateByPrimaryKeyWithBLOBs(record);
	}

	@Override
	public int updateByPrimaryKey(Message record) {
		// TODO Auto-generated method stub
		return messageMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public List<Message> SelectMessages() {
		// TODO Auto-generated method stub
		return messageMapper.SelectMessages();
	}

	@Override
	public List<Message> SelectMessagesBySourceID(String sourceid) {
		// TODO Auto-generated method stub
		return messageMapper.SelectMessagesBySourceID(sourceid);
	}

	@Override
	public int DeleteBySourceID(String sourceid) {
		// TODO Auto-generated method stub
		return messageMapper.DeleteBySourceID(sourceid);
	}
	

}
