package com.advance.serviceImp;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.advance.mapper.ActivityMapper;
import com.advance.model.Activity;
import com.advance.service.ActivityService;
/**
 * @author advance
 */
@Service
public class ActivityServiceImp implements ActivityService {

	@Resource
	private ActivityMapper activityMapper;
	@Override
	public int deleteByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return activityMapper.deleteByPrimaryKey(id);
	}

	@Override
	public int insert(Activity record) {
		// TODO Auto-generated method stub
		return activityMapper.insert(record);
	}

	@Override
	public int insertSelective(Activity record) {
		// TODO Auto-generated method stub
		return activityMapper.insertSelective(record);
	}

	@Override
	public Activity selectByPrimaryKey(String id) {
		// TODO Auto-generated method stub
		return activityMapper.selectByPrimaryKey(id);
	}

	@Override
	public int updateByPrimaryKeySelective(Activity record) {
		// TODO Auto-generated method stub
		return activityMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public int updateByPrimaryKeyWithBLOBs(Activity record) {
		// TODO Auto-generated method stub
		return activityMapper.updateByPrimaryKeyWithBLOBs(record);
	}

	@Override
	public int updateByPrimaryKey(Activity record) {
		// TODO Auto-generated method stub
		return activityMapper.updateByPrimaryKeySelective(record);
	}

	@Override
	public List<Activity> SelectActivitys() {
		// TODO Auto-generated method stub
		return activityMapper.SelectActivitys();
	}

	@Override
	public List<Activity> SelectActivitysByClassID(String classid) {
		// TODO Auto-generated method stub
		return activityMapper.SelectActivitysByClassID(classid);
	}

	@Override
	public List<Activity> SelectActivitysByExamUserID(String examuserid) {
		// TODO Auto-generated method stub
		return activityMapper.SelectActivitysByExamUserID(examuserid);
	}

	@Override
	public List<Activity> SelectActivitysByApplicantID(String applicantid) {
		// TODO Auto-generated method stub
		return activityMapper.SelectActivitysByApplicantID(applicantid);
	}
	
	
}
