$(function(){ 

    $('.alert-box').hide();


    /*
        Fullscreen background
    */
    $.backstretch([
        "assets/img/backgrounds/2.jpg", "assets/img/backgrounds/3.jpg", "assets/img/backgrounds/1.jpg"
    ], {
        duration: 3000,
        fade: 750
    });

    /*
        Form validation
    */
    $('.login-form input[type="text"], .login-form input[type="password"], .login-form textarea').on('focus', function () {
        $(this).removeClass('input-error');
    });

});

$('.btn').on('click', function (e) {

    var error = 0;

    $('.login-form').find('input[type="text"], input[type="password"], textarea').each(function () {
        if ($(this).val().trim() == "") {
            e.preventDefault();
            $(this).addClass('input-error');
            error++;
        } else {
            $(this).removeClass('input-error');
        }
    });

    if (error == 0) {

        $.ajax({
            type: 'POST',
            url: 'User/Login.do',
            data: $('.loginform').serialize(),
            dataType: 'json',
            success: function (data) {
            	console.log(data);
                    if (data.status == true) {
                    	$.cookie('id', data.result.id); 
                    	$.cookie('userid', data.result.userid); 
                    	$.cookie('username', data.result.username); 
                    	$.cookie('usertype', data.result.usertype); 
                        window.location.href = "main.html"
                    } else {
                        alertMessage('.alert-box', 'alert-danger', data.massege);
                    }

                },
                error: function () {
                    alertMessage('.alert-box', 'alert-danger', '请求接口异常');
                }
        });

    }

});

function alertMessage(ui, addclass, message) {
    $(ui).addClass(addclass).html('<strong> ' + message + '</strong>').show();
    setTimeout(function () {
        $(ui).hide()
    }, 2000);
}