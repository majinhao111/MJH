﻿$(function () {

    if ($.cookie('userid') == null || $.cookie('username') == null || $.cookie('usertype') == null) {
        window.location.href = "login.html";
    }

    $('.navi-page').load("index.html");

    $('.menu-exit').click(function () {
        $.cookie('userid', null);
        $.cookie('username', null);
        $.cookie('usertype', null);
        window.location.href = "login.html";
    });

    $('.user-userid').text($.cookie('userid'));
    $('.user-username').text($.cookie('username'));

    $.ajax({
        url: "Menu/GetMenu.do",
        type: "post",
        datatype: "json",
        data: {
            "Type": $.cookie('usertype')
        },
        success: function (data) {
                if (data.status == true) {
                    $.each(data.result, function (i, v) {
                        $('.nav-menu').append("<li><a src=\"" + v.url + "\" class=\"navi-url\"><i ></i> <span>" + v.name + "</span></a></li>");
                    });
                }
            },
            error: function () {
                window.location.href = "login.html";
            }
    });

    $('.nav-menu').on("click", ".navi-url", function () {

        $('.navi-page').html("");

        $(".navi-url").each(function () {
            $(this).removeClass('active');
        });

        var $this = $(this);
        var href = $this.attr('src');
        $this.addClass('active');
        $('.navi-page').load(href);
    });

    toastr.options = {
        "closeButton": false,
        "debug": false,
        "newestOnTop": false,
        "progressBar": true,
        "positionClass": "toast-top-right",
        "preventDuplicates": false,
        "onclick": null,
        "showDuration": "300",
        "hideDuration": "1000",
        "timeOut": "2000",
        "extendedTimeOut": "1000",
        "showEasing": "swing",
        "hideEasing": "linear",
        "showMethod": "fadeIn",
        "hideMethod": "fadeOut"
    };

});