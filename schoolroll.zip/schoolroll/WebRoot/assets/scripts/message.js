﻿$(function() {
    
    $(".btn-primary").click(function(){
    	
    	var error = 0;
        $('.form-horizontal').find('input[type="text"], input[type="number"],textarea').each(function () {
            if ($(this).val().trim() == "") {
                e.preventDefault();
                $(this).addClass('input-error');
                error++;
            } else {
                $(this).removeClass('input-error');
            }
        });
    	
        if(error!=0){return;}
        
    	var posturl='Message/Insert.do';
    	
    	if($('#id').val()!='')
    	{
    		posturl='Message/Update.do';
    	}
    	
        $.ajax({
           type: 'POST',
           url: posturl,
           data: $('.form-horizontal').serialize(),
           dataType: 'json',
           success: function (data) {
                   if (data.status == true) {
                       TableLoadData();
                       toastr.success("操作成功");  
                       $('#myModal').modal('hide');
                   } else {
                	   toastr.error(data.massege);  
                   }

               },
               error: function () {
            	   toastr.error("操作失败");  
               }
           });
    });
    
    TableLoadData();
});

$('#myModal').on('hide.bs.modal', function () {
	$('#sourceid').val("");
	$('.form-horizontal').find('textarea').each(function () {
        $(this).val("");
    });
});

function TableLoadData() {
	$.ajax({
        type: 'POST',
        url: 'Message/SelectList.do',
        dataType: 'json',
        success: function (data) {
        	if (data.status == true) {
             createShowingTable(data.result);
        	}
            },
            error: function () {
         	   toastr.error("操作失败");  
            }
        });
	
};

//动态的创建一个table
function createShowingTable(data) {
	var tableStr = "<table  border='1' bordercolor='#a0c6e5' style='line-height:30px;border-collapse:collapse;width:99%;'>";
	$.each(data, function (i, v) {
	     tableStr +="<tr>"
		 tableStr += "<td style='width:65%;text-algin:left;padding-left:20px;font-weight:bold;'>留言标题："+ v.content + "</td>"
		 tableStr +="<td style='width:20%;text-algin:left;padding-left:20px;font-weight:bold;'>留言人："+ v.createusername+" ("+ dateFtt("yyyy-MM-dd hh:mm:ss",new Date(v.createtime))+")</td>"
		 tableStr +="<td style='width:10%;text-algin:left;padding-left:20px;font-weight:bold;'><a style='cursor:pointer;' onclick=messageAt('"+v.id+"')>我要评论</a></td>"
		 tableStr +="<td style='width:5%;text-algin:left;padding-left:20px;font-weight:bold;'>"
		// if(v.createuserid==$.cookie('userid'))
		// {
		 tableStr +="<a style='cursor:pointer;' onclick=removeAt('"+v.id+"')>删除</a></td>";
		 //}
	     tableStr +="</td>"
		 tableStr +="</tr>";
	     if(v.messagelist.length>0){
	    	 
	    	 tableStr+="<tr>";
	    		tableStr+="<td colspan='4' style='padding-top:10px;padding-bottom:10px;'>";
	    		tableStr +="<table style='line-height:30px;width:80%;'>";
	    		 $.each(v.messagelist, function (g, a) {
	    			 tableStr+="<tr>";
	    			 tableStr +="<td style='padding-left:30px;font-weight:bold;'>评论人:"+ a.createusername+" ("+ dateFtt("yyyy-MM-dd hh:mm:ss",new Date(a.createtime))+")"
	    			// if(a.createuserid==$.cookie('userid'))
	    			// {
	    			 tableStr +="<a style='cursor:pointer;' onclick=removeAt('"+a.id+"')>删除</a></td>";
	    			// }
	    			 tableStr +="</td>";
	    			 tableStr+="</tr>";
	    			 tableStr+="<tr>";
	    			 tableStr +="<td style='padding-left:30px;'>评论内容:"+a.content;
	    			 tableStr +="</td>";
	    			 tableStr+="</tr>";
	    		 });
	    		 tableStr +="</table>";
	    		 tableStr +="</td>";
	    		 tableStr +="</tr>";
	     }
	});
    tableStr += "</table>";
	//添加到div中
	$(".table-datasource").html(tableStr);
}



function dateFtt(fmt,date)   
{ //author: meizz   
  var o = {   
    "M+" : date.getMonth()+1,                 //月份   
    "d+" : date.getDate(),                    //日   
    "h+" : date.getHours(),                   //小时   
    "m+" : date.getMinutes(),                 //分   
    "s+" : date.getSeconds(),                 //秒   
    "q+" : Math.floor((date.getMonth()+3)/3), //季度   
    "S"  : date.getMilliseconds()             //毫秒   
  };   
  if(/(y+)/.test(fmt))   
    fmt=fmt.replace(RegExp.$1, (date.getFullYear()+"").substr(4 - RegExp.$1.length));   
  for(var k in o)   
    if(new RegExp("("+ k +")").test(fmt))   
  fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));   
  return fmt;   
} 

function removeAt(id)
{
	
	swal({ 
		  title: '确认删除选中数据行？', 
		  text: '你将无法恢复它！', 
		  type: 'warning',
		  showCancelButton: true, 
		  confirmButtonText: '确定',
		  cancelButtonText: '取消',
		}).then(function(){
			$.ajax({
		        type: 'POST',
		        url: 'Message/Delete.do',
		        data: {"ID":id},
		        dataType: 'json',
		        success: function (data) {
		                if (data.status == true) {
		                    TableLoadData();
		                    toastr.success("操作成功");  
		                } else {
		             	   toastr.error(data.massege);  
		                }

		            },
		            error: function () {
		         	   toastr.error("操作失败");  
		            }
		        });
		})
		}

function messageAt(id)
{
	$('#myModal').modal();
	$('#sourceid').val(id);
}