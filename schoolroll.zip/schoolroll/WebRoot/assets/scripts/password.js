﻿$(function () {

	$(".btn-primary").click(function () {
		$.ajax({
            type: 'POST',
            url: 'User/PassWord.do',
            data: $('.form-horizontal').serialize(),
            dataType: 'json',
            success: function (data) {
                    if (data.status == true) {
                        toastr.success("操作成功");
                    } else {
                        toastr.error(data.massege);
                    }

                },
                error: function () {
                    toastr.error("操作失败");
                }
        });
    });
});