﻿$(function () {
    TableInit();

    $(".btn-primary").click(function () {

        var error = 0;
        $('.form-horizontal').find('input[type="text"], input[type="number"]').each(function () {
            if ($(this).val().trim() == "") {
                e.preventDefault();
                $(this).addClass('input-error');
                error++;
            } else {
                $(this).removeClass('input-error');
            }
        });

        if (error != 0) {
            return;
        }
        
        $.ajax({
            type: 'POST',
            url: 'Schoolroll/Update.do',
            data: $('.form-horizontal').serialize(),
            dataType: 'json',
            success: function (data) {
                    if (data.status == true) {
                        toastr.success("操作成功");
                    } else {
                        toastr.error(data.massege);
                    }

                },
                error: function () {
                    toastr.error("操作失败");
                }
        });
        
    });

    $.ajax({
        type: 'POST',
        url: 'College/Select.do',
        dataType: 'json',
        success: function (data) {
                $('#collegeid').empty();
                $(data).each(function (key) {
                    $('#collegeid').append("<option value='" + data[key].id + "'> " + data[key].collegename + "</option>");
                });
            },
            error: function () {
                toastr.error("请求学院信息失败");
            }
    });
    
    $.ajax({
        type: 'POST',
        url: 'Major/Select.do',
        dataType: 'json',
        success: function (data) {
                $('#majorid').empty();
                $(data).each(function (key) {
                    $('#majorid').append("<option value='" + data[key].id + "'> " + data[key].majorname + "</option>");
                });
            },
            error: function () {
                toastr.error("请求专业信息失败");
            }
    });
    
    $.ajax({
        type: 'POST',
        url: 'Class/Select.do',
        dataType: 'json',
        success: function (data) {
                $('#classid').empty();
                $(data).each(function (key) {
                    $('#classid').append("<option value='" + data[key].id + "'> " + data[key].classname + "</option>");
                });
            },
            error: function () {
                toastr.error("请求班级信息失败");
            }
    });
    
    $.ajax({
        type: 'POST',
        url: 'Schoolroll/SelectBySchoolRollID.do',
        dataType: 'json',
        success: function (data) {
        	
        	if (data.status == true) {
        		
        		$('#id').val(data.result.id);
                $('#schoolrollid').text(data.result.schoolrollid);
                $('#name').val(data.result.name);
                $('#sex').val(data.result.sex);
                $('#birthday').val(dateFormat_1(data.result.birthday));
                $('#nation').val(data.result.nation);
                $('#birthplace').val(data.result.birthplace);
                $('#address').val(data.result.address);
                $('#identitycard').val(data.result.identitycard);
                $('#zipcode').val(data.result.zipcode);
                $('#entrancedate').val(dateFormat_1(data.result.entrancedate));
                $('#education').val(data.result.education);
                $("#collegeid option:contains('"+row.collegeid+"')").attr("selected", true);
                $("#majorid option:contains('"+row.majorid+"')").attr("selected", true);
                $("#classid option:contains('"+row.classid+"')").attr("selected", true);
                
            } else {
                toastr.error(data.massege);
            }
            },
            error: function () {
                toastr.error("请求学籍信息失败");
            }
    });

});
function dateFormat_1(longTypeDate){ 
	  var dateType = ""; 
	  var date = new Date(); 
	  date.setTime(longTypeDate); 
	  dateType += date.getFullYear();  //年 
	  dateType += "-" + getMonth(date); //月  
	  dateType += "-" + getDay(date);  //日 
	  return dateType;
	} 
	//返回 01-12 的月份值  
	function getMonth(date){ 
	  var month = ""; 
	  month = date.getMonth() + 1; //getMonth()得到的月份是0-11 
	  if(month<10){ 
	    month = "0" + month; 
	  } 
	  return month; 
	} 
	//返回01-30的日期 
	function getDay(date){ 
	  var day = ""; 
	  day = date.getDate(); 
	  if(day<10){ 
	    day = "0" + day; 
	  } 
	  return day; 
	}
$(function () {
    $('#birthday').datetimepicker({  
    	autoclose: true,
        minView: "month", //选择日期后，不会再跳转去选择时分秒
        language: 'zh-CN',
        format: "yyyy-mm-dd",
        pickerPosition: "bottom-right",
    });  
    
    $('#entrancedate').datetimepicker({  
    	autoclose: true,
        minView: "month", //选择日期后，不会再跳转去选择时分秒
        language: 'zh-CN',
        format: "yyyy-mm-dd",
        pickerPosition: "bottom-right",
    });  
});  
