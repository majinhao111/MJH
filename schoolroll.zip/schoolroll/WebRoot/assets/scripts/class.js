﻿$(function () {
    TableInit();

    $(".btn-primary").click(function () {

        var error = 0;
        $('.form-horizontal').find('input[type="text"], input[type="number"]').each(function () {
            if ($(this).val().trim() == "") {
                e.preventDefault();
                $(this).addClass('input-error');
                error++;
            } else {
                $(this).removeClass('input-error');
            }
        });

        if (error != 0) {
            return;
        }

        var posturl = 'Class/Insert.do';

        if ($('#id').val() != '') {
            posturl = 'Class/Update.do';
        }

        $.ajax({
            type: 'POST',
            url: posturl,
            data: $('.form-horizontal').serialize(),
            dataType: 'json',
            success: function (data) {
                    if (data.status == true) {
                        TableLoadData();
                        toastr.success("操作成功");
                        $('#myModal').modal('hide');
                    } else {
                        toastr.error(data.massege);
                    }

                },
                error: function () {
                    toastr.error("操作失败");
                }
        });
    });

    $.ajax({
        type: 'POST',
        url: 'College/Select.do',
        dataType: 'json',
        success: function (data) {
                $('#collegeid').empty();
                $(data).each(function (key) {
                    $('#collegeid').append("<option value='" + data[key].id + "'> " + data[key].collegename + "</option>");
                });
            },
            error: function () {
                toastr.error("请求学院信息失败");
            }
    });

    $.ajax({
        type: 'POST',
        url: 'Major/Select.do',
        dataType: 'json',
        success: function (data) {
                $('#majorid').empty();
                $(data).each(function (key) {
                    $('#majorid').append("<option value='" + data[key].id + "'> " + data[key].majorname + "</option>");
                });
            },
            error: function () {
                toastr.error("请求专业信息失败");
            }
    });

});

$('#myModal').on('hide.bs.modal', function () {
    $('.form-horizontal').find('input').each(function () {
        $(this).val("");
    });
});


function TableLoadData() {
    $('.table-datasource').bootstrapTable('refresh', {
        url: 'Class/Select.do'
    });
};

function TableInit() {
    $('.table-datasource').bootstrapTable('destroy').bootstrapTable({
        url: 'Class/Select.do',
        //请求后台的URL（*）
        method: 'POST',
        //请求方式（*）
        toolbar: '.toolbar',
        //工具按钮用哪个容器
        striped: true,
        //是否显示行间隔色
        cache: false,
        //是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
        pagination: true,
        //是否显示分页（*）
        sortable: true,
        //是否启用排序
        sortOrder: "asc",
        //排序方式
        sidePagination: "client",
        //分页方式：client客户端分页，server服务端分页（*）
        pageNumber: 1,
        //初始化加载第一页，默认第一页
        pageSize: 10,
        //每页的记录行数（*）
        pageList: [10, 25, 50, 100],
        //可供选择的每页的行数（*）
        search: true,
        //是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
        strictSearch: true,
        showColumns: true,
        //是否显示所有的列
        showRefresh: true,
        //是否显示刷新按钮
        minimumCountColumns: 2,
        //最少允许的列数
        clickToSelect: true,
        //是否启用点击选中行
        uniqueId: "ID",
        //每一行的唯一标识，一般为主键列
        showToggle: false,
        //是否显示详细视图和列表视图的切换按钮
        cardView: false,
        //是否显示详细视图
        detailView: false,
        //是否显示父子表
        uniqueId: 'id',
        //主键
        showExport: true,
        //显示导出
        exportDataType: 'all',
        exportTypes: ['csv', 'txt', 'excel'],
        //导出类型
        exportOptions: {
            fileName: new Date().getTime()
        },
        //导出名称
        columns: [{
            field: "index",
            title: "ID",
            align: "center",
            formatter: function (value, row, index) {
                return row.index = index + 1; //返回行号  
            }
        }, {
            field: 'id',
            align: "center",
            title: 'id',
            visible: false,
        }, {
            field: 'classid',
            align: "center",
            title: '班级编号',
            sortable: true
        }, {
            field: 'classname',
            align: "center",
            title: '班级名称',
            sortable: true
        }, {
            field: 'classnumber',
            align: "center",
            title: '班级人数',
            sortable: true
        }, {
            field: 'collegeid',
            align: "center",
            title: '学院名称',
            sortable: true
        }, {
            field: 'majorid',
            align: "center",
            title: '专业名称',
            sortable: true
        }, {
            title: "操作",
            align: "center",
            width: '10%',
            formatter: function (value, row, index) {
                var strHtml = "<div class=\"center\"><a><li onclick=\"removeAt('" + row.id + "')\" class=\"glyphicon glyphicon-remove\"></li></div>";
                return strHtml;
            },
        }, ],
        onDblClickRow: function (row) {
            $('#myModal').modal();
            $('#id').val(row.id);
            $('#classid').val(row.classid);
            $('#classname').val(row.classname);
            $('#classnumber').val(row.classnumber);
            $("#collegeid option:contains('"+row.collegeid+"')").attr("selected", true);
            $("#majorid option:contains('"+row.majorid+"')").attr("selected", true);
        }
    });
};

function removeAt(id) {

    swal({
        title: '确认删除选中数据行？',
        text: '你将无法恢复它！',
        type: 'warning',
        showCancelButton: true,
        confirmButtonText: '确定',
        cancelButtonText: '取消',
    }).then(function () {
        $.ajax({
            type: 'POST',
            url: 'Class/Delete.do',
            data: {
                "ID": id
            },
            dataType: 'json',
            success: function (data) {
                    if (data.status == true) {
                        TableLoadData();
                        toastr.success("操作成功");
                    } else {
                        toastr.error(data.massege);
                    }

                },
                error: function () {
                    toastr.error("操作失败");
                }
        });
    })
}