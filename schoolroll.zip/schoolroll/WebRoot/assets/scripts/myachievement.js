﻿$(function () {
    TableInit();
});

function TableLoadData() {
    $('.table-datasource').bootstrapTable('refresh', {
        url: 'Achievement/SelectBySchoolRollID.do'
    });
};

function TableInit() {
    $('.table-datasource').bootstrapTable('destroy').bootstrapTable({
        url: 'Achievement/SelectBySchoolRollID.do',
        //请求后台的URL（*）
        method: 'POST',
        //请求方式（*）
        toolbar: '.toolbar',
        //工具按钮用哪个容器
        striped: true,
        //是否显示行间隔色
        cache: false,
        //是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
        pagination: true,
        //是否显示分页（*）
        sortable: true,
        //是否启用排序
        sortOrder: "asc",
        //排序方式
        sidePagination: "client",
        //分页方式：client客户端分页，server服务端分页（*）
        pageNumber: 1,
        //初始化加载第一页，默认第一页
        pageSize: 10,
        //每页的记录行数（*）
        pageList: [10, 25, 50, 100],
        //可供选择的每页的行数（*）
        search: true,
        //是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
        strictSearch: true,
        showColumns: true,
        //是否显示所有的列
        showRefresh: true,
        //是否显示刷新按钮
        minimumCountColumns: 2,
        //最少允许的列数
        clickToSelect: true,
        //是否启用点击选中行
        uniqueId: "ID",
        //每一行的唯一标识，一般为主键列
        showToggle: false,
        //是否显示详细视图和列表视图的切换按钮
        cardView: false,
        //是否显示详细视图
        detailView: false,
        //是否显示父子表
        uniqueId: 'id',
        //主键
        showExport: true,
        //显示导出
        exportDataType: 'all',
        exportTypes: ['csv', 'txt', 'excel'],
        //导出类型
        exportOptions: {
            fileName: new Date().getTime()
        },
        //导出名称
        columns: [{
            field: "index",
            title: "ID",
            align: "center",
            formatter: function (value, row, index) {
                return row.index = index + 1; //返回行号  
            }
        }, {
            field: 'id',
            align: "center",
            title: 'id',
            visible: false,
        }, {
            field: 'schoolrollid',
            align: "center",
            title: '学生姓名',
            sortable: true
        }, {
            field: 'curriculumid',
            align: "center",
            title: '课程名称',
            sortable: true
        }, {
            field: 'fraction',
            align: "center",
            title: '分数',
            sortable: true
        },],
    });
};