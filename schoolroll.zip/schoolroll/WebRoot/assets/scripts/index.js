﻿$(function() {
    TableInit();
});

function TableLoadData() {
    $('.table-datasource').bootstrapTable({
        url: 'Notice/Select.do'
    });
};

function dateFtt(fmt,date)   
{ //author: meizz   
  var o = {   
    "M+" : date.getMonth()+1,                 //月份   
    "d+" : date.getDate(),                    //日   
    "h+" : date.getHours(),                   //小时   
    "m+" : date.getMinutes(),                 //分   
    "s+" : date.getSeconds(),                 //秒   
    "q+" : Math.floor((date.getMonth()+3)/3), //季度   
    "S"  : date.getMilliseconds()             //毫秒   
  };   
  if(/(y+)/.test(fmt))   
    fmt=fmt.replace(RegExp.$1, (date.getFullYear()+"").substr(4 - RegExp.$1.length));   
  for(var k in o)   
    if(new RegExp("("+ k +")").test(fmt))   
  fmt = fmt.replace(RegExp.$1, (RegExp.$1.length==1) ? (o[k]) : (("00"+ o[k]).substr((""+ o[k]).length)));   
  return fmt;   
} 

function TableInit() {
    $('.table-datasource').bootstrapTable('destroy').bootstrapTable({
        url: 'Notice/Select.do',
        //请求后台的URL（*）
        method: 'POST',
        //请求方式（*）
       // toolbar: '.toolbar',
        //工具按钮用哪个容器
        striped: true,
        //是否显示行间隔色
        cache: false,
        //是否使用缓存，默认为true，所以一般情况下需要设置一下这个属性（*）
        pagination: true,
        //是否显示分页（*）
        sortable: true,
        //是否启用排序
        sortOrder: "asc",
        //排序方式
        sidePagination: "client",
        //分页方式：client客户端分页，server服务端分页（*）
        pageNumber: 1,
        //初始化加载第一页，默认第一页
        pageSize: 10,
        //每页的记录行数（*）
        pageList: [10, 25, 50, 100],
        //可供选择的每页的行数（*）
        search: true,
        //是否显示表格搜索，此搜索是客户端搜索，不会进服务端，所以，个人感觉意义不大
        strictSearch: true,
        showColumns: true,
        //是否显示所有的列
        showRefresh: true,
        //是否显示刷新按钮
        minimumCountColumns: 2,
        //最少允许的列数
        clickToSelect: true,
        //是否启用点击选中行
        uniqueId: "ID",
        //每一行的唯一标识，一般为主键列
        showToggle: false,
        //是否显示详细视图和列表视图的切换按钮
        cardView: false,
        //是否显示详细视图
        detailView: false,
        //是否显示父子表
        uniqueId: 'id',
        //主键
        showExport: true,
        //显示导出
        exportDataType: 'all',
        exportTypes: ['csv', 'txt', 'excel'],
        //导出类型
        exportOptions: {
            fileName: new Date().getTime()
        },
        columns: [{
            field: "index",
            title: "ID",
            align: "center",
            formatter: function(value, row, index) {
                return row.index = index+1; //返回行号  
            }
        },{
            field: 'id',
            title: 'id',
            visible: false
        },{
            field: 'content',
            title: 'content',
            visible: false
        }, {
            field: 'title',
            align: "center",
            title: '活动标题',
            width:'50%',
            sortable: true
        }, {
            field: 'createusername',
            align: "center",
            title: '发布人',
            width:'25%',
            sortable: true
        }, {
            field: 'createtime',
            align: "center",
            title: '发布时间',
            width:'25%',
            sortable: true,
            formatter: function crtTimeFtt(value,row,index){
		    var crtTime = new Date(value);
		    return top.dateFtt("yyyy-MM-dd hh:mm:ss",crtTime);//直接调用公共JS里面的时间类处理的办法     
		    }
        },],
        onDblClickRow: function (row) {
            $('.modal-dialog').css({"width":"70%"});
            $('#myModalLabel').text(row.title);
            $('#myModalContent').text(row.content);
            $('#myModal').modal();
         }
    });
};